// ╔══════════════════════════════════════════╗
// ║          OVL-MD-V2  — INDEX.JS          ║
// ║     Bot WhatsApp Multi-Device Complet   ║
// ║          Développé par : Livaï          ║
// ╚══════════════════════════════════════════╝

const {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");

const pino      = require("pino");
const NodeCache = require("node-cache");
const config    = require("./config");
const store_    = require("./lib/store");
const { log, getBody, getSender, isOwner, isGroup, isAdmin } = require("./lib/utils");

// ── Import commandes ──────────────────────────────────────
const menuCmd   = require("./commands/menu");
const conf      = require("./commands/confidentialite");
const conv      = require("./commands/conversion");
const fun       = require("./commands/fun");
const funEx     = require("./commands/fun_extra");
const fx        = require("./commands/fx_audio");
const groupe    = require("./commands/groupe");
const ia        = require("./commands/ia");
const imgEdit   = require("./commands/image_edits");
const imgEx     = require("./commands/image_edits_extra");
const logo      = require("./commands/logo");
const outils    = require("./commands/outils");
const econ      = require("./commands/economy");
const games     = require("./commands/games");
const ownerCmd  = require("./commands/owner");
const ownerEx   = require("./commands/owner_extra");
const reaction  = require("./commands/reaction");
const search    = require("./commands/search");
const status    = require("./commands/status");
const systeme   = require("./commands/systeme");
const dl        = require("./commands/telechargement");

// ── Router global ─────────────────────────────────────────
const COMMANDS = {
  // Menu
  menu: menuCmd, aide: menuCmd, help: menuCmd, allmenu: menuCmd,

  // Confidentialité
  getprivacy: conf.getprivacy, groupadd: conf.groupadd,
  lastseen: conf.lastseen, mypp: conf.mypp, mystatus: conf.mystatus,
  online: conf.online, presence: conf.presence, read: conf.read, setbio: conf.setbio,

  // Conversion
  sticker: conv.sticker, s: conv.sticker,
  toimage: conv.toimage, toaudio: conv.toaudio,
  tts: conv.tts, ttp: conv.ttp, attp: conv.attp,
  url: conv.url, write: conv.write, circle: conv.circle,
  crop: conv.crop, remini: conv.remini, round: conv.round,
  fusion: conv.fusion, quotely: conv.quotely, emix: conv.emix,
  take: conv.take, stickertovideo: conv.stickertovideo, tovideo: conv.tovideo,

  // Fun
  blague: fun.blague, citation: fun.citation, ship: fun.ship,
  couplepp: funEx.couplepp, fake: funEx.fake, fancy: fun.fancy,
  fliptext: fun.fliptext, readmore: fun.readmore,
  profile: funEx.profile, rank: funEx.rank, toprank: funEx.toprank,
  truth: funEx.truth, dare: funEx.dare,
  "8ball": funEx.eightball, roast: funEx.roast, compliment: funEx.compliment,
  dice: funEx.dice, coinflip: funEx.coinflip, pp: funEx.pp,
  doublestruck: imgEx.doublestruck, bold: imgEx.bold,
  italic: imgEx.italic, smallcaps: imgEx.smallcaps, bubbletext: imgEx.bubbletext,

  // FX Audio (40 effets)
  alien: fx.alien, bass: fx.bass, blown: fx.blown, buzz: fx.buzz,
  cave: fx.cave, chipmunk: fx.chipmunk, chorus: fx.chorus,
  compressor: fx.compressor, dark: fx.dark, deep: fx.deep,
  distortion: fx.distortion, dizzy: fx.dizzy, earrape: fx.earrape,
  echo: fx.echo, fast: fx.fast, fat: fx.fat, flanger: fx.flanger,
  ghost: fx.ghost, haunting: fx.haunting, invert: fx.invert,
  lofi: fx.lofi, mono: fx.mono, muted: fx.muted, nightcore: fx.nightcore,
  panorama: fx.panorama, phaser: fx.phaser, radio: fx.radio,
  reverb: fx.reverb, reverse: fx.reverse, robot: fx.robot,
  slow: fx.slow, smooth: fx.smooth, space: fx.space,
  squirrel: fx.squirrel, surround: fx.surround, telephone: fx.telephone,
  tremolo: fx.tremolo, underwater: fx.underwater, vibrato: fx.vibrato,
  vintage: fx.vintage,

  // Groupe
  acceptall: groupe.acceptall, antibot: groupe.antibot,
  antidemote: groupe.antidemote, antilink: groupe.antilink,
  antimentiongc: groupe.antimentiongc, antipromote: groupe.antipromote,
  antispam: groupe.antispam, antitag: groupe.antitag,
  ckick: groupe.ckick, close: groupe.close, demote: groupe.demote,
  demotealert: groupe.demotealert, gccreate: groupe.gccreate,
  gdesc: groupe.gdesc, getpp: groupe.getpp, ginfo: groupe.ginfo,
  gname: groupe.gname, goodbye: groupe.goodbye, join: groupe.join,
  kick: groupe.kick, kickall: groupe.kickall, kickall2: groupe.kickall,
  leave: groupe.leave, link: groupe.link, lock: groupe.lock,
  open: groupe.open, poll: groupe.poll, poll2: groupe.poll2,
  promote: groupe.promote, promotealert: groupe.promotealert,
  rejectall: groupe.rejectall, removepp: groupe.removepp,
  revoke: groupe.revoke, tag: groupe.tag, tagadmin: groupe.tagadmin,
  tagall: groupe.tagall, everyone: groupe.tagall,
  unlock: groupe.unlock, updatepp: groupe.updatepp,
  vcf: groupe.vcf, warn: groupe.warn, welcome: groupe.welcome,
  mute: groupe.mute, unmute: groupe.unmute,

  // IA
  gpt: ia.gpt, gemini: ia.gemini, claude: ia.claude,
  blackbox: ia.blackbox, copilot: ia.copilot, llama: ia.llama, dalle: ia.dalle,

  // Image Edits
  affect: imgEdit.affect, beautiful: imgEdit.beautiful,
  blur: imgEdit.blur, circle1: imgEdit.circle1, colorfy: imgEdit.colorfy,
  darkness: imgEdit.darkness, delete_image: imgEdit.delete_image,
  facepalmm: imgEdit.facepalmm, greyscale: imgEdit.greyscale,
  invert1: imgEdit.invert1, jail: imgEdit.jail,
  jokeoverhead: imgEdit.jokeoverhead, pixelate: imgEdit.pixelate,
  rainbow: imgEdit.rainbow, rip: imgEdit.rip, sepia: imgEdit.sepia,
  threshold: imgEdit.threshold, trash: imgEdit.trash,
  trigger: imgEdit.trigger, wanted: imgEdit.wanted, wasted: imgEdit.wasted,
  shit: imgEx.shit, hitler: imgEx.hitler, whoasked: imgEx.whoasked,

  // Logo (50+ styles)
  ...logo,

  // Outils
  ping: outils.ping, uptime: outils.uptime, owner: outils.owner,
  developpeur: outils.developpeur, system_status: outils.system_status,
  translate: outils.translate, qr: outils.qr,
  tempmail: outils.tempmail, tempinbox: outils.tempinbox,
  capture: outils.capture, repo: outils.repo, support: outils.support,
  pair: outils.pair, test: outils.test,
  tovv: outils.tovv, vv: outils.vv, vv2: outils.vv2,
  obfuscate: outils.obfuscate, description: outils.description,
  theme: outils.theme, gitclone: outils.gitclone,

  // Economy
  bonus: econ.bonus, capacite: econ.capacite, depot: econ.depot,
  don: econ.don, myecon: econ.myecon, pari: econ.pari,
  resetaccount: econ.resetaccount, retrait: econ.retrait,
  slot: econ.slot, transfer: econ.transfer, vol: econ.vol,

  // Games
  "anime-quizz": games.anime_quizz, dmots: games.dmots,
  tictactoe: games.tictactoe, wcg: games.wcg,

  // Owner
  ban: ownerCmd.ban, deban: ownerCmd.deban,
  block: ownerCmd.block, deblock: ownerCmd.deblock,
  restart: ownerCmd.restart, disconnect: ownerCmd.disconnect,
  clear: ownerCmd.clear,
  setsudo: ownerCmd.setsudo, delsudo: ownerCmd.delsudo, sudolist: ownerCmd.sudolist,
  jid: ownerCmd.jid, anticall: ownerCmd.anticall, antidelete: ownerCmd.antidelete,
  chatbot: ownerCmd.chatbot, tgs: ownerCmd.tgs,
  delete: ownerCmd.delete, bangroup: ownerCmd.bangroupCmd,
  debangroup: ownerCmd.debangroupCmd,

  // Owner Extra
  addstickercmd: ownerEx.addstickercmd,
  delstickercmd: ownerEx.delstickercmd,
  getstickercmd: ownerEx.getstickercmd,
  setprivate_cmd: ownerEx.setprivate_cmd,
  delprivate_cmd: ownerEx.delprivate_cmd,
  listprivate_cmd: ownerEx.listprivate_cmd,
  setpublic_cmd: ownerEx.setpublic_cmd,
  delpublic_cmd: ownerEx.delpublic_cmd,
  listpublic_cmd: ownerEx.listpublic_cmd,
  connect_session: ownerEx.connect_session,
  fetch_sc: ownerEx.fetch_sc,
  setmention: ownerEx.setmention,
  getmention: ownerEx.getmention,
  delmention: ownerEx.delmention,
  react_msg: ownerEx.react_msg,
  lecture_msg: ownerEx.lecture_msg,
  pginstall: ownerEx.pginstall,
  pgremove: ownerEx.pgremove,
  pglist: ownerEx.pglist,
  levelup: ownerEx.levelup,
  onlyadmins: ownerEx.onlyadmins,

  // Réaction (27)
  ...reaction,

  // Search
  anime: search.anime, github: search.github, google: search.google,
  imdb: search.imdb, img: search.img, lyrics: search.lyrics,
  meteo: search.meteo, shazam: search.shazam,
  stickersearch: search.stickersearch, wiki: search.wiki,

  // Status
  dl_status: status.dl_status, lecture_status: status.lecture_status,
  likestatus: status.likestatus, save: status.save, sendme: status.sendme,

  // Système
  checkupdate: systeme.checkupdate, delvar: systeme.delvar,
  getvar: systeme.getvar, setvar: systeme.setvar, update: systeme.update,

  // Téléchargement
  app: dl.app, fbdl: dl.fbdl, igdl: dl.igdl, song: dl.song,
  tiktok: dl.tiktok, tiktokaudio: dl.tiktokaudio,
  tiktokimage: dl.tiktokimage, twitterdl: dl.twitterdl,
  video: dl.video, yta: dl.yta, ytv: dl.ytv,
};

const cooldowns = new Map();
const msgRetryCounterCache = new NodeCache();
const readline = require("readline");

// ── Demander le numéro dans le terminal ───────────────────
function askPhoneNumber() {
  return new Promise((resolve) => {
    // Si le numéro est déjà dans config, on l'utilise directement
    if (config.OWNER_NUMBER && !config.OWNER_NUMBER.includes("X")) {
      resolve(config.OWNER_NUMBER.replace(/\D/g, ""));
      return;
    }
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question("\n📱 Entre ton numéro WhatsApp (ex: 242XXXXXXXXX) : ", (num) => {
      rl.close();
      resolve(num.replace(/\D/g, ""));
    });
  });
}

// ── Charger SESSION_ID depuis variable d'environnement ────
function loadSessionFromEnv() {
  const SESSION_ID = process.env.SESSION_ID;
  if (!SESSION_ID || !SESSION_ID.startsWith("LIVAI_SESSION~")) return;

  try {
    const encoded = SESSION_ID.replace("LIVAI_SESSION~", "");
    const bundle  = JSON.parse(Buffer.from(encoded, "base64").toString("utf8"));
    const authDir = config.SESSION_DIR;

    if (!require("fs").existsSync(authDir)) {
      require("fs").mkdirSync(authDir, { recursive: true });
    }

    for (const [filename, b64] of Object.entries(bundle)) {
      require("fs").writeFileSync(
        require("path").join(authDir, filename),
        Buffer.from(b64, "base64")
      );
    }
    log("ok", "✅ Session chargée depuis SESSION_ID !");
  } catch (e) {
    log("warn", "SESSION_ID invalide, démarrage normal : " + e.message);
  }
}

async function startBot() {
  loadSessionFromEnv();
  const { state, saveCreds } = await useMultiFileAuthState(config.SESSION_DIR);
  const { version }          = await fetchLatestBaileysVersion();

  log("info", `Démarrage ${config.BOT_NAME} v${config.VERSION}...`);
  log("info", `📦 ${Object.keys(COMMANDS).length} commandes chargées`);

  const sock = makeWASocket({
    version,
    auth:                     state,
    printQRInTerminal:        false,   // QR désactivé → on utilise le Pairing Code
    logger:                   pino({ level: "silent" }),
    msgRetryCounterCache,
    generateHighQualityLinkPreview: true,
    browser:                  ["Livaï MD", "Chrome", "120.0.0"],
  });

  // ── Pairing Code (si pas encore connecté) ────────────────
  sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {

    // Dès qu'on a besoin d'un QR → on demande le Pairing Code à la place
    if (qr && !sock.authState.creds.registered) {
      try {
        const phone = await askPhoneNumber();
        if (!phone || phone.length < 8) {
          log("err", "Numéro invalide. Relance le bot et réessaie.");
          process.exit(1);
        }

        log("info", `📲 Génération du code pour +${phone}...`);
        const code = await sock.requestPairingCode(phone);

        // Afficher le code bien visible dans les logs
        const formatted = code.match(/.{1,4}/g).join("-"); // ex: ABCD-EFGH
        console.log("\n");
        console.log("╔══════════════════════════════════╗");
        console.log("║     🔑  TON CODE DE CONNEXION    ║");
        console.log("║                                  ║");
        console.log(`║         ${formatted.padEnd(26)}║`);
        console.log("║                                  ║");
        console.log("╠══════════════════════════════════╣");
        console.log("║  1. Ouvre WhatsApp sur ton tel   ║");
        console.log("║  2. Paramètres → Appareils liés  ║");
        console.log("║  3. Lier un appareil              ║");
        console.log("║  4. Entre le code ci-dessus      ║");
        console.log("╚══════════════════════════════════╝");
        console.log("\n");

      } catch (err) {
        log("err", `Impossible de générer le Pairing Code : ${err.message}`);
        log("warn", "Relance le bot et réessaie.");
        process.exit(1);
      }
    }

    if (connection === "open") {
      log("ok",   `✅ ${config.BOT_NAME} connecté !`);
      log("info", `👑 Owner : ${config.OWNER_NAME} | 🔰 Préfixe : ${config.PREFIX}`);
    }

    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      if (shouldReconnect) {
        log("warn", "Reconnexion en cours...");
        setTimeout(startBot, 4000);
      } else {
        log("err", "Déconnecté définitivement. Supprime ./auth_info et relance.");
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  // ── Événements groupe (welcome / goodbye / alerts) ────
  sock.ev.on("group-participants.update", async ({ id, participants, action }) => {
    const s = store_.load();
    for (const jid of participants) {
      const name = `@${jid.split("@")[0]}`;
      try {
        if (action === "add"    && s.welcomeGroups?.[id]) {
          await sock.sendMessage(id, { text: s.welcomeGroups[id].replace(/@user/g, name), mentions: [jid] });
        }
        if (action === "remove" && s.goodbyeGroups?.[id]) {
          await sock.sendMessage(id, { text: s.goodbyeGroups[id].replace(/@user/g, name), mentions: [jid] });
        }
        if (action === "promote" && store_.has("promotealertGroups", id)) {
          await sock.sendMessage(id, { text: `👑 ${name} est maintenant admin !`, mentions: [jid] });
        }
        if (action === "demote"  && store_.has("demotealertGroups", id)) {
          await sock.sendMessage(id, { text: `⬇️ ${name} n'est plus admin.`, mentions: [jid] });
        }
      } catch {}
    }
  });

  // ── Messages ──────────────────────────────────────────
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const msg  = messages[0];
    if (!msg?.message || msg.key.fromMe) return;

    const from   = msg.key.remoteJid;
    const sender = getSender(msg);
    const body   = getBody(msg).trim();
    const s      = store_.load();

    // Bans
    if (s.bans?.[sender] || s.groupBans?.[from]) return;

    // XP système (compte tous les messages)
    if (isGroup(msg)) {
      try { funEx.addXP(sender); } catch {}
    }

    // Anti-delete
    if (store_.has("antidelete", "global") && msg.message?.protocolMessage?.type === 0) {
      try {
        const del = msg.message.protocolMessage.key;
        await sock.sendMessage(from, {
          text: `🗑 *Anti-Delete* — Message supprimé par @${del.participant?.split("@")[0] || sender.split("@")[0]}`,
          mentions: [del.participant || sender],
        });
      } catch {}
    }

    // Sans préfixe → jeux + chatbot
    if (!body.startsWith(config.PREFIX)) {
      if (isGroup(msg)) {
        await games.handleGameReply(sock, msg, from, body).catch(() => {});
      }
      if (store_.has("chatbotGroups", from) && body.length > 1) {
        try {
          const res = await require("axios").post("https://api.blackbox.ai/api/chat", {
            messages: [{ role:"user", content: body }], stream: false,
          });
          const reply = res.data?.choices?.[0]?.message?.content;
          if (reply) await sock.sendMessage(from, { text: reply }, { quoted: msg });
        } catch {}
      }
      return;
    }

    // Mode privé
    const mode   = s.mode || (config.PUBLIC_MODE ? "public" : "private");
    const isSudo = s.sudoList?.includes(sender);
    if (mode === "private" && !isOwner(msg) && !isSudo) return;

    // Extraire commande
    const args    = body.slice(config.PREFIX.length).trim().split(/\s+/);
    const command = args.shift().toLowerCase();

    // Anti-spam
    const coolKey = `${sender}-${command}`;
    if (cooldowns.has(coolKey)) {
      const left = (cooldowns.get(coolKey) - Date.now()) / 1000;
      if (left > 0) return sock.sendMessage(from, {
        text: `⏳ Attends *${left.toFixed(1)}s* avant de réutiliser cette commande.`
      });
    }
    cooldowns.set(coolKey, Date.now() + config.COOLDOWN);
    setTimeout(() => cooldowns.delete(coolKey), config.COOLDOWN);

    // Anti-lien
    if (isGroup(msg) && store_.has("antilinkGroups", from)) {
      const hasLink = /(https?:\/\/|wa\.me|chat\.whatsapp)/i.test(body);
      if (hasLink) {
        const adm = await isAdmin(sock, from, sender).catch(() => false);
        if (!adm && !isOwner(msg)) {
          await sock.sendMessage(from, { delete: msg.key });
          await sock.sendMessage(from, {
            text: `⚠️ @${sender.split("@")[0]}, les liens sont interdits !`,
            mentions: [sender],
          });
          return;
        }
      }
    }

    log("info", `[${isGroup(msg)?"GRP":"DM"}] ${sender.split("@")[0]} → ${config.PREFIX}${command}`);

    // 1. Chercher dans COMMANDS statiques
    const fn = COMMANDS[command];
    if (fn) {
      try { await fn(sock, msg, from, args); } catch (err) {
        log("err", `[${command}] ${err.message}`);
        await sock.sendMessage(from, { text: `❌ Erreur : _${err.message}_` });
      }
      return;
    }

    // 2. Chercher dans les sticker cmds dynamiques
    const foundStick = await ownerEx.handleStickerCmd(sock, msg, from, command).catch(() => false);
    if (foundStick) return;

    // 3. Chercher dans les commandes custom (pub/priv)
    const foundCustom = await ownerEx.handleCustomCmd(sock, msg, from, command, isOwner(msg)).catch(() => false);
    if (foundCustom) return;

    // Commande inconnue
    await sock.sendMessage(from, {
      text: `❓ Commande *${config.PREFIX}${command}* introuvable.\nTape *${config.PREFIX}menu* pour voir toutes les commandes.`,
    });
  });

  return sock;
}

require("fs-extra").ensureDirSync("./data");
startBot().catch(err => {
  log("err", `Fatal: ${err.message}`);
  process.exit(1);
});
