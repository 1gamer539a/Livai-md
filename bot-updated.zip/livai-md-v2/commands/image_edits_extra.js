// ╭──⟪ IMAGE EDITS EXTRA ⟫──╮
const axios  = require("axios");
const { getQuoted } = require("../lib/utils");

async function getImgBuf(sock, msg) {
  const q = getQuoted(msg);
  if (q?.imageMessage) return sock.downloadMediaMessage({ message: q });
  if (msg.message?.imageMessage) return sock.downloadMediaMessage(msg);
  return null;
}

async function apiEdit(sock, msg, from, endpoint, caption) {
  const buf = await getImgBuf(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: "❌ Réponds à une image." });
  try {
    const res = await axios.get(
      `https://api.popcat.xyz/${endpoint}?image=${encodeURIComponent("data:image/png;base64,"+buf.toString("base64"))}`,
      { responseType: "arraybuffer" }
    );
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption });
  } catch {
    // Fallback siputzx
    try {
      const res2 = await axios.post(`https://api.siputzx.my.id/api/filter/${endpoint}`,
        { image: buf.toString("base64") }, { responseType: "arraybuffer" });
      await sock.sendMessage(from, { image: Buffer.from(res2.data), caption });
    } catch {
      await sock.sendMessage(from, { text: `❌ Erreur lors du traitement (${endpoint}).` });
    }
  }
}

// Commandes manquantes
const shit      = (s,m,f) => apiEdit(s,m,f, "shit",      "💩 Shit");
const hitler    = (s,m,f) => apiEdit(s,m,f, "hitler",    "😡 Hitler");
const delete2   = (s,m,f) => apiEdit(s,m,f, "delete",    "🗑 Deleted");

// Commandes supplémentaires fun image
async function whoasked(sock, msg, from) {
  try {
    const res = await axios.get("https://api.popcat.xyz/whoasked", { responseType:"arraybuffer" });
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption: "🤷 Who asked?" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur whoasked." });
  }
}

async function doublestruck(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: "❌ Usage : .doublestruck <texte>" });
  const map = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const dbl = "𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡";
  const out = text.split("").map(c => { const i = map.indexOf(c); return i >= 0 ? dbl[i] : c; }).join("");
  await sock.sendMessage(from, { text: `𝔻𝕠𝕦𝕓𝕝𝕖𝕊𝕥𝕣𝕦𝕔𝕜\n\n${out}` });
}

async function bold(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: "❌ Usage : .bold <texte>" });
  const map = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const bld = "𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭";
  const out = text.split("").map(c => { const i = map.indexOf(c); return i >= 0 ? bld[i] : c; }).join("");
  await sock.sendMessage(from, { text: `𝗕𝗼𝗹𝗱\n\n${out}` });
}

async function italic(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: "❌ Usage : .italic <texte>" });
  const map = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const itl = "𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡";
  const out = text.split("").map(c => { const i = map.indexOf(c); return i >= 0 ? itl[i] : c; }).join("");
  await sock.sendMessage(from, { text: `𝘐𝘵𝘢𝘭𝘪𝘤\n\n${out}` });
}

async function smallcaps(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: "❌ Usage : .smallcaps <texte>" });
  const map = "abcdefghijklmnopqrstuvwxyz";
  const sc  = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢ";
  const out = text.toLowerCase().split("").map(c => { const i = map.indexOf(c); return i >= 0 ? sc[i] : c; }).join("");
  await sock.sendMessage(from, { text: `ꜱᴍᴀʟʟᴄᴀᴘꜱ\n\n${out}` });
}

async function bubbletext(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: "❌ Usage : .bubbletext <texte>" });
  const map = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const bub = "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ①②③④⑤⑥⑦⑧⑨⓪";
  const out = text.split("").map(c => { const i = map.indexOf(c); return i >= 0 ? bub[i] : c; }).join("");
  await sock.sendMessage(from, { text: `ⓑⓤⓑⓑⓛⓔ\n\n${out}` });
}

module.exports = { shit, hitler, delete2, whoasked, doublestruck, bold, italic, smallcaps, bubbletext };
