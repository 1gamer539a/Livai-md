// ╭──⟪ CONFIDENTIALITÉ ⟫──╮
const config = require("../config");

async function getprivacy(sock, msg, from) {
  const privacy = await sock.fetchPrivacySettings(true);
  const fmt = (v) => ({ all:"Tout le monde", contacts:"Mes contacts", none:"Personne" }[v] || v);
  await sock.sendMessage(from, {
    text: `🔒 *Tes paramètres de confidentialité*\n\n` +
      `• Dernière vue : ${fmt(privacy.last)}\n` +
      `• Photo de profil : ${fmt(privacy.profile)}\n` +
      `• À propos : ${fmt(privacy.status)}\n` +
      `• Groupes : ${fmt(privacy.groupadd)}\n` +
      `• Statuts : ${fmt(privacy.readreceipts)}`
  });
}

async function groupadd(sock, msg, from, args) {
  const val = args[0];
  if (!["all","contacts","none"].includes(val))
    return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}groupadd [all|contacts|none]` });
  await sock.updateGroupsAddPrivacy(val);
  await sock.sendMessage(from, { text: `✅ Qui peut t'ajouter aux groupes : *${val}*` });
}

async function lastseen(sock, msg, from, args) {
  const val = args[0];
  if (!["all","contacts","none"].includes(val))
    return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}lastseen [all|contacts|none]` });
  await sock.updateLastSeenPrivacy(val);
  await sock.sendMessage(from, { text: `✅ Dernière vue : *${val}*` });
}

async function mypp(sock, msg, from) {
  try {
    const sender = msg.key.participant || msg.key.remoteJid;
    const url = await sock.profilePictureUrl(sender, "image");
    await sock.sendMessage(from, { image: { url }, caption: "🖼 *Ta photo de profil*" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Aucune photo de profil trouvée." });
  }
}

async function mystatus(sock, msg, from) {
  await sock.sendMessage(from, { text: "ℹ️ Commande mystatus disponible via l'API WhatsApp Business." });
}

async function online(sock, msg, from, args) {
  const val = args[0] === "off" ? "offline" : "available";
  await sock.sendPresenceUpdate(val, from);
  await sock.sendMessage(from, { text: `✅ Présence : *${val}*` });
}

async function presence(sock, msg, from, args) {
  const types = ["available","unavailable","composing","recording","paused"];
  const val = args[0];
  if (!types.includes(val))
    return sock.sendMessage(from, { text: `❌ Types : ${types.join(", ")}` });
  await sock.sendPresenceUpdate(val, from);
  await sock.sendMessage(from, { text: `✅ Présence définie sur *${val}*` });
}

async function read(sock, msg, from) {
  await sock.readMessages([msg.key]);
  await sock.sendMessage(from, { text: "✅ Message marqué comme lu." });
}

async function setbio(sock, msg, from, args) {
  const bio = args.join(" ");
  if (!bio) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}setbio <texte>` });
  await sock.updateProfileStatus(bio);
  await sock.sendMessage(from, { text: `✅ Bio mise à jour : _${bio}_` });
}

module.exports = { getprivacy, groupadd, lastseen, mypp, mystatus, online, presence, read, setbio };
