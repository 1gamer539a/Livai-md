// ╭──⟪ OVL-ECONOMY ⟫──╮
const config = require("../config");
const econ   = require("../lib/economy");
const { getSender, getMentioned, isOwner } = require("../lib/utils");

async function myecon(sock, msg, from) {
  const jid = getSender(msg);
  const acc  = econ.getAccount(jid);
  await sock.sendMessage(from, {
    text: `💰 *Ton compte*\n\n• Solde : *${acc.solde} coins*\n• Dépôt total : *${acc.depot} coins*\n• Victoires : *${acc.wins}*\n• Défaites : *${acc.losses}*`
  });
}

async function depot(sock, msg, from, args) {
  const amount = parseInt(args[0]);
  if (!amount || amount <= 0) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}depot <montant>` });
  const jid  = getSender(msg);
  const acc  = econ.getAccount(jid);
  acc.solde += amount;
  acc.depot += amount;
  econ.setAccount(jid, acc);
  await sock.sendMessage(from, { text: `✅ *+${amount} coins* déposés.\nNouveau solde : *${acc.solde} coins*` });
}

async function retrait(sock, msg, from, args) {
  const amount = parseInt(args[0]);
  if (!amount || amount <= 0) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}retrait <montant>` });
  const jid = getSender(msg);
  const acc = econ.getAccount(jid);
  if (acc.solde < amount) return sock.sendMessage(from, { text: `❌ Solde insuffisant. Tu as *${acc.solde} coins*.` });
  acc.solde -= amount;
  econ.setAccount(jid, acc);
  await sock.sendMessage(from, { text: `✅ *-${amount} coins* retirés.\nNouveau solde : *${acc.solde} coins*` });
}

async function transfer(sock, msg, from, args) {
  const targets = getMentioned(msg);
  const amount  = parseInt(args.find(a => !isNaN(a)));
  if (!targets.length || !amount) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}transfer @quelquun <montant>` });
  const sender = getSender(msg);
  const from_  = econ.getAccount(sender);
  if (from_.solde < amount) return sock.sendMessage(from, { text: `❌ Solde insuffisant.` });
  econ.removeSolde(sender, amount);
  econ.addSolde(targets[0], amount);
  await sock.sendMessage(from, { text: `💸 *${amount} coins* transférés à @${targets[0].split("@")[0]} !`, mentions:[targets[0]] });
}

async function don(sock, msg, from, args) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  const targets = getMentioned(msg);
  const amount  = parseInt(args.find(a=>!isNaN(a))) || 1000;
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}don @quelquun <montant>` });
  econ.addSolde(targets[0], amount);
  await sock.sendMessage(from, { text: `🎁 *${amount} coins* offerts à @${targets[0].split("@")[0]} !`, mentions:[targets[0]] });
}

async function bonus(sock, msg, from) {
  const jid  = getSender(msg);
  const acc  = econ.getAccount(jid);
  const last = acc.lastBonus || 0;
  const now  = Date.now();
  if (now - last < 24*60*60*1000) {
    const remaining = Math.ceil((24*60*60*1000 - (now-last)) / 3600000);
    return sock.sendMessage(from, { text: `⏳ Bonus déjà réclamé. Reviens dans *${remaining}h*` });
  }
  const amount = Math.floor(Math.random()*500) + 100;
  acc.solde += amount;
  acc.lastBonus = now;
  econ.setAccount(jid, acc);
  await sock.sendMessage(from, { text: `🎉 Bonus quotidien : *+${amount} coins* !\nSolde : *${acc.solde} coins*` });
}

async function slot(sock, msg, from, args) {
  const bet = parseInt(args[0]) || 100;
  const jid = getSender(msg);
  const acc = econ.getAccount(jid);
  if (acc.solde < bet) return sock.sendMessage(from, { text: `❌ Solde insuffisant. Tu as *${acc.solde} coins*.` });
  const items = ["🍒","🍋","🍊","🍇","⭐","💎"];
  const s = [items[Math.floor(Math.random()*items.length)], items[Math.floor(Math.random()*items.length)], items[Math.floor(Math.random()*items.length)]];
  const win = s[0]===s[1] && s[1]===s[2];
  if (win) { acc.solde += bet*3; acc.wins++; } else { acc.solde -= bet; acc.losses++; }
  econ.setAccount(jid, acc);
  await sock.sendMessage(from, {
    text: `🎰 *SLOT MACHINE*\n\n| ${s.join(" | ")} |\n\n${win?`🎉 JACKPOT ! *+${bet*3} coins*`:`😔 Perdu ! *-${bet} coins*`}\nSolde : *${acc.solde} coins*`
  });
}

async function pari(sock, msg, from, args) {
  const bet = parseInt(args[0]) || 100;
  const jid = getSender(msg);
  const acc = econ.getAccount(jid);
  if (acc.solde < bet) return sock.sendMessage(from, { text: `❌ Solde insuffisant.` });
  const win = Math.random() > 0.5;
  if (win) { acc.solde += bet; acc.wins++; } else { acc.solde -= bet; acc.losses++; }
  econ.setAccount(jid, acc);
  await sock.sendMessage(from, {
    text: `🎲 *Pari*\n\n${win?`🎉 Gagné ! *+${bet} coins*`:`😔 Perdu ! *-${bet} coins*`}\nSolde : *${acc.solde} coins*`
  });
}

async function vol(sock, msg, from, args) {
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}vol @quelquun` });
  const jid    = getSender(msg);
  const target = targets[0];
  const tAcc   = econ.getAccount(target);
  if (tAcc.solde < 100) return sock.sendMessage(from, { text: "❌ Cette personne n'a pas assez de coins." });
  const success = Math.random() > 0.4;
  if (success) {
    const stolen = Math.floor(Math.random() * Math.min(tAcc.solde, 500)) + 50;
    econ.removeSolde(target, stolen);
    econ.addSolde(jid, stolen);
    await sock.sendMessage(from, { text: `🦹 Vol réussi ! Tu as volé *${stolen} coins* à @${target.split("@")[0]}`, mentions:[target] });
  } else {
    econ.removeSolde(jid, 200);
    await sock.sendMessage(from, { text: `🚔 Vol raté ! Tu as perdu *200 coins*.` });
  }
}

async function capacite(sock, msg, from) {
  const jid = getSender(msg);
  const acc = econ.getAccount(jid);
  await sock.sendMessage(from, { text: `💼 *Capacité*\n\n• Solde max : illimité\n• Solde actuel : *${acc.solde} coins*` });
}

async function resetaccount(sock, msg, from) {
  const jid = getSender(msg);
  econ.resetAccount(jid);
  await sock.sendMessage(from, { text: "✅ Ton compte a été réinitialisé." });
}

module.exports = { myecon, depot, retrait, transfer, don, bonus, slot, pari, vol, capacite, resetaccount };
