// ╭──⟪ FUN EXTRA ⟫──╮
const axios  = require("axios");
const config = require("../config");
const { getSender, getMentioned } = require("../lib/utils");

// ── Compteur de messages pour rank ────────────────────────
const fs   = require("fs-extra");
const path = require("path");
const RANK_FILE = path.join(__dirname, "../data/rank.json");
function loadRank() { return fs.existsSync(RANK_FILE) ? fs.readJsonSync(RANK_FILE) : {}; }
function saveRank(d){ fs.writeJsonSync(RANK_FILE, d, { spaces:2 }); }

function addXP(jid, amount = 1) {
  const d = loadRank();
  if (!d[jid]) d[jid] = { xp: 0, level: 1, messages: 0 };
  d[jid].xp       += amount;
  d[jid].messages += 1;
  // Level up tous les 100 XP
  while (d[jid].xp >= d[jid].level * 100) {
    d[jid].xp   -= d[jid].level * 100;
    d[jid].level += 1;
  }
  saveRank(d);
  return d[jid];
}

async function rank(sock, msg, from) {
  const jid  = getSender(msg);
  const d    = loadRank();
  const data = d[jid] || { xp: 0, level: 1, messages: 0 };
  const next  = data.level * 100;
  const bar   = "█".repeat(Math.floor((data.xp/next)*10)) + "░".repeat(10-Math.floor((data.xp/next)*10));
  await sock.sendMessage(from, {
    text: `🏆 *Ton Rang*\n\n👤 ${msg.pushName || jid.split("@")[0]}\n⭐ Niveau : *${data.level}*\n📊 XP : *${data.xp}/${next}*\n${bar}\n💬 Messages : *${data.messages}*`
  });
}

async function toprank(sock, msg, from) {
  const d    = loadRank();
  const sorted = Object.entries(d)
    .sort((a,b) => b[1].level - a[1].level || b[1].xp - a[1].xp)
    .slice(0, 10);
  if (!sorted.length) return sock.sendMessage(from, { text: "ℹ️ Pas encore de classement." });
  const medals = ["🥇","🥈","🥉","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"];
  const txt = sorted.map(([jid, data], i) =>
    `${medals[i]} +${jid.split("@")[0]} — Niv. *${data.level}* (${data.messages} msgs)`
  ).join("\n");
  await sock.sendMessage(from, { text: `🏅 *Top 10 Classement*\n\n${txt}` });
}

// ── Profil complet ────────────────────────────────────────
async function profile(sock, msg, from) {
  const targets = getMentioned(msg);
  const jid     = targets[0] || getSender(msg);
  const d       = loadRank();
  const data    = d[jid] || { xp: 0, level: 1, messages: 0 };
  const name    = jid === getSender(msg) ? (msg.pushName || jid.split("@")[0]) : jid.split("@")[0];
  try {
    const pp  = await sock.profilePictureUrl(jid, "image");
    await sock.sendMessage(from, {
      image: { url: pp },
      caption: `👤 *Profil de ${name}*\n\n📱 Numéro : +${jid.split("@")[0]}\n⭐ Niveau : *${data.level}*\n💬 Messages : *${data.messages}*\n📊 XP : *${data.xp}*`
    });
  } catch {
    await sock.sendMessage(from, {
      text: `👤 *Profil de ${name}*\n\n📱 Numéro : +${jid.split("@")[0]}\n⭐ Niveau : *${data.level}*\n💬 Messages : *${data.messages}*`
    });
  }
}

// ── Couple PP ─────────────────────────────────────────────
async function couplepp(sock, msg, from) {
  const targets = getMentioned(msg);
  if (targets.length < 2) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}couplepp @p1 @p2` });
  try {
    const url1 = await sock.profilePictureUrl(targets[0], "image");
    const url2 = await sock.profilePictureUrl(targets[1], "image");
    const pct  = Math.floor(Math.random() * 101);
    await sock.sendMessage(from, {
      image: { url: url1 },
      caption: `💑 *Couple PP*\n\n@${targets[0].split("@")[0]} ❤️ @${targets[1].split("@")[0]}\n\n💞 Compatibilité : *${pct}%*`,
      mentions: targets
    });
  } catch {
    await sock.sendMessage(from, {
      text: `💑 @${targets[0].split("@")[0]} ❤️ @${targets[1].split("@")[0]}\n\n💞 ${Math.floor(Math.random()*101)}%`,
      mentions: targets
    });
  }
}

// ── Fake profil ───────────────────────────────────────────
async function fake(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}fake <texte>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/maker/fake?text=${encodeURIComponent(text)}`, { responseType:"arraybuffer" });
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption: "📱 Faux message WhatsApp" });
  } catch {
    await sock.sendMessage(from, { text: `📱 *Fake Message*\n\n_"${text}"_` });
  }
}

// ── Truth or Dare ─────────────────────────────────────────
const truths = [
  "Quelle est ta plus grande peur ?",
  "As-tu déjà menti à tes parents ?",
  "Quelle est la chose la plus embarrassante que tu aies faite ?",
  "As-tu déjà eu le béguin pour quelqu'un dans ce groupe ?",
  "Quel est ton secret le plus honteux ?",
];
const dares = [
  "Envoie une photo de ton écran d'accueil.",
  "Fais une dédicace à quelqu'un dans ce groupe.",
  "Envoie un vocal de 10 secondes en chantant.",
  "Change ta photo de profil pendant 1 heure.",
  "Envoie ton dernier message copié.",
];

async function truth(sock, msg, from) {
  const q = truths[Math.floor(Math.random()*truths.length)];
  await sock.sendMessage(from, { text: `🤔 *Vérité*\n\n_${q}_` });
}

async function dare(sock, msg, from) {
  const d = dares[Math.floor(Math.random()*dares.length)];
  await sock.sendMessage(from, { text: `😈 *Défi*\n\n_${d}_` });
}

// ── 8ball ────────────────────────────────────────────────
async function eightball(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}8ball <question>` });
  const responses = [
    "✅ Oui, absolument !","✅ C'est certain.","✅ Sans aucun doute.",
    "🤔 Peut-être...","🤔 Difficile à dire.","🤔 Pas sûr.",
    "❌ Non.","❌ Certainement pas.","❌ Ne compte pas là-dessus.",
  ];
  const r = responses[Math.floor(Math.random()*responses.length)];
  await sock.sendMessage(from, { text: `🎱 *8Ball*\n\n❓ _${q}_\n\n${r}` });
}

// ── Roast ────────────────────────────────────────────────
async function roast(sock, msg, from, args) {
  const targets = getMentioned(msg);
  const name    = targets.length ? `@${targets[0].split("@")[0]}` : args[0] || "toi";
  const roasts  = [
    `${name} tu es tellement lent que même Google Maps te met en mode piéton automatiquement. 😂`,
    `${name} ton Wi-Fi est plus rapide que tes idées. 💀`,
    `${name} même ton téléphone se met en mode avion pour fuir tes blagues. ✈️`,
    `${name} tu as le charisme d'un ongle de pied. 😭`,
    `${name} si la bêtise était un sport, tu serais médaillé d'or. 🥇`,
  ];
  await sock.sendMessage(from, {
    text: `🔥 *Roast*\n\n${roasts[Math.floor(Math.random()*roasts.length)]}`,
    mentions: targets
  });
}

// ── Compliment ───────────────────────────────────────────
async function compliment(sock, msg, from, args) {
  const targets  = getMentioned(msg);
  const name     = targets.length ? `@${targets[0].split("@")[0]}` : args[0] || "toi";
  const compliments = [
    `${name}, tu es comme le soleil — tu illumines tout autour de toi ! ☀️`,
    `${name}, tu as un cœur en or. 💛`,
    `${name}, le monde est meilleur grâce à toi. 🌍`,
    `${name}, tu es une inspiration pour tous ! 🌟`,
    `${name}, ta gentillesse est sans pareille. 💕`,
  ];
  await sock.sendMessage(from, {
    text: `💐 *Compliment*\n\n${compliments[Math.floor(Math.random()*compliments.length)]}`,
    mentions: targets
  });
}

// ── Dice ────────────────────────────────────────────────
async function dice(sock, msg, from, args) {
  const faces = parseInt(args[0]) || 6;
  const result = Math.floor(Math.random() * faces) + 1;
  await sock.sendMessage(from, { text: `🎲 *Dé à ${faces} faces*\n\nRésultat : *${result}*` });
}

// ── Coinflip ─────────────────────────────────────────────
async function coinflip(sock, msg, from) {
  const result = Math.random() > 0.5 ? "🪙 Face" : "🪙 Pile";
  await sock.sendMessage(from, { text: `${result} !` });
}

// ── PP (photo de profil de quelqu'un) ────────────────────
async function pp(sock, msg, from) {
  const targets = getMentioned(msg);
  const jid     = targets[0] || getSender(msg);
  try {
    const url = await sock.profilePictureUrl(jid, "image");
    await sock.sendMessage(from, { image: { url }, caption: `🖼 Photo de profil de @${jid.split("@")[0]}`, mentions: [jid] });
  } catch {
    await sock.sendMessage(from, { text: `❌ @${jid.split("@")[0]} n'a pas de photo de profil.`, mentions: [jid] });
  }
}

module.exports = {
  rank, toprank, profile, couplepp, fake,
  truth, dare, eightball, roast, compliment,
  dice, coinflip, pp, addXP,
};
