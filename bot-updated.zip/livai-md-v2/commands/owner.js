// ╭──⟪ OWNER ⟫──╮
const config = require("../config");
const store  = require("../lib/store");
const { isOwner, getSender, getMentioned } = require("../lib/utils");

function ownerOnly(fn) {
  return async (sock, msg, from, args) => {
    if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
    return fn(sock, msg, from, args);
  };
}

const ban = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}ban @quelquun` });
  const s = store.load();
  if (!s.bans) s.bans = {};
  targets.forEach(t => { s.bans[t] = true; });
  store.save(s);
  await sock.sendMessage(from, { text: `✅ ${targets.map(t=>"@"+t.split("@")[0]).join(", ")} banni(s).`, mentions: targets });
});

const deban = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  const s = store.load();
  if (!s.bans) s.bans = {};
  targets.forEach(t => { delete s.bans[t]; });
  store.save(s);
  await sock.sendMessage(from, { text: `✅ ${targets.map(t=>"@"+t.split("@")[0]).join(", ")} débanni(s).`, mentions: targets });
});

const block = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}block @quelquun` });
  for (const t of targets) await sock.updateBlockStatus(t, "block");
  await sock.sendMessage(from, { text: `✅ ${targets.length} contact(s) bloqué(s).` });
});

const deblock = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  for (const t of targets) await sock.updateBlockStatus(t, "unblock");
  await sock.sendMessage(from, { text: `✅ ${targets.length} contact(s) débloqué(s).` });
});

const restart = ownerOnly(async (sock, msg, from) => {
  await sock.sendMessage(from, { text: "🔄 Redémarrage du bot..." });
  process.exit(0);
});

const disconnect = ownerOnly(async (sock, msg, from) => {
  await sock.sendMessage(from, { text: "👋 Déconnexion en cours..." });
  await sock.logout();
});

const clear = ownerOnly(async (sock, msg, from) => {
  await sock.chatModify({ clear: { messages: [{ id: "all", fromMe: true }] } }, from);
  await sock.sendMessage(from, { text: "🗑 Chat effacé." });
});

const setpublic = ownerOnly(async (sock, msg, from) => {
  const s = store.load();
  s.mode = "public";
  store.save(s);
  await sock.sendMessage(from, { text: "✅ Bot en mode *public*." });
});

const setprivate = ownerOnly(async (sock, msg, from) => {
  const s = store.load();
  s.mode = "private";
  store.save(s);
  await sock.sendMessage(from, { text: "✅ Bot en mode *privé* (owner seulement)." });
});

const setsudo = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}setsudo @quelquun` });
  const s = store.load();
  if (!s.sudoList) s.sudoList = [];
  targets.forEach(t => { if (!s.sudoList.includes(t)) s.sudoList.push(t); });
  store.save(s);
  await sock.sendMessage(from, { text: `✅ Sudo ajouté : ${targets.map(t=>"@"+t.split("@")[0]).join(", ")}`, mentions: targets });
});

const delsudo = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  const s = store.load();
  if (!s.sudoList) s.sudoList = [];
  s.sudoList = s.sudoList.filter(x => !targets.includes(x));
  store.save(s);
  await sock.sendMessage(from, { text: `✅ Sudo retiré.` });
});

const sudolist = ownerOnly(async (sock, msg, from) => {
  const s = store.load();
  const list = s.sudoList || [];
  await sock.sendMessage(from, { text: `👥 *Liste Sudo*\n\n${list.length?list.map(j=>"+"+j.split("@")[0]).join("\n"):"Aucun sudo."}` });
});

const jid = ownerOnly(async (sock, msg, from) => {
  await sock.sendMessage(from, { text: `🆔 *JID*\n\nChat : \`${from}\`\nToi : \`${getSender(msg)}\`` });
});

const anticall = ownerOnly(async (sock, msg, from, args) => {
  const active = store.toggle("anticall", "global");
  await sock.sendMessage(from, { text: `📞 Anti-call : *${active?"✅ Activé":"❌ Désactivé"}*` });
});

const antidelete = ownerOnly(async (sock, msg, from) => {
  const active = store.toggle("antidelete", "global");
  await sock.sendMessage(from, { text: `🗑 Anti-delete : *${active?"✅ Activé":"❌ Désactivé"}*` });
});

const chatbot = ownerOnly(async (sock, msg, from, args) => {
  const active = store.toggle("chatbotGroups", from);
  await sock.sendMessage(from, { text: `🤖 ChatBot : *${active?"✅ Activé":"❌ Désactivé"}*` });
});

const levelup = ownerOnly(async (sock, msg, from) => {
  await sock.sendMessage(from, { text: "⬆️ LevelUp system — à configurer avec ta base de données." });
});

const onlyadmins = ownerOnly(async (sock, msg, from) => {
  const active = store.toggle("onlyadmins", from);
  await sock.sendMessage(from, { text: `🔐 Only Admins : *${active?"✅ Activé":"❌ Désactivé"}*` });
});

const tgs = ownerOnly(async (sock, msg, from, args) => {
  // Envoyer un message dans tous les groupes
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}tgs <message>` });
  const groups = Object.keys((await sock.groupFetchAllParticipating())||{});
  let count = 0;
  for (const g of groups) {
    try { await sock.sendMessage(g, { text }); count++; } catch {}
  }
  await sock.sendMessage(from, { text: `✅ Message envoyé dans *${count}* groupes.` });
});

const delete_ = ownerOnly(async (sock, msg, from) => {
  const { getQuoted } = require("../lib/utils");
  const q = getQuoted(msg);
  if (!q) return sock.sendMessage(from, { text: "❌ Réponds au message à supprimer." });
  const key = msg.message?.extendedTextMessage?.contextInfo;
  if (key?.stanzaId) {
    await sock.sendMessage(from, { delete: { ...msg.key, id: key.stanzaId, participant: key.participant, fromMe: key.participant === sock.user.id } });
  }
});

const bangroupCmd = ownerOnly(async (sock, msg, from) => {
  const s = store.load();
  if (!s.groupBans) s.groupBans = {};
  s.groupBans[from] = true;
  store.save(s);
  await sock.sendMessage(from, { text: "✅ Groupe banni." });
  await sock.groupLeave(from).catch(()=>{});
});

const debangroupCmd = ownerOnly(async (sock, msg, from, args) => {
  const gid = args[0] || from;
  const s = store.load();
  if (!s.groupBans) s.groupBans = {};
  delete s.groupBans[gid];
  store.save(s);
  await sock.sendMessage(from, { text: `✅ Groupe \`${gid}\` débanni.` });
});

module.exports = {
  ban, deban, block, deblock, restart, disconnect, clear,
  setpublic_cmd: setpublic, setprivate_cmd: setprivate,
  setsudo, delsudo, sudolist, jid, anticall, antidelete,
  chatbot, levelup, onlyadmins, tgs, delete: delete_,
  bangroupCmd, debangroupCmd,
};
