// ╭──⟪ CONVERSION ⟫──╮
const axios  = require("axios");
const config = require("../config");
const { getQuoted } = require("../lib/utils");

// Helper : télécharger le média quoté
async function getMediaBuffer(sock, msg) {
  const quoted = getQuoted(msg);
  if (!quoted) return null;
  const types = ["imageMessage","videoMessage","audioMessage","stickerMessage","documentMessage"];
  for (const t of types) {
    if (quoted[t]) {
      return await sock.downloadMediaMessage({ message: quoted });
    }
  }
  return null;
}

async function sticker(sock, msg, from) {
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à une image/vidéo avec ${config.PREFIX}sticker` });
  await sock.sendMessage(from, { sticker: buf });
}

async function toimage(sock, msg, from) {
  const quoted = getQuoted(msg);
  if (!quoted?.stickerMessage)
    return sock.sendMessage(from, { text: `❌ Réponds à un sticker avec ${config.PREFIX}toimage` });
  const buf = await sock.downloadMediaMessage({ message: quoted });
  await sock.sendMessage(from, { image: buf, caption: "🖼 Converti en image" });
}

async function toaudio(sock, msg, from) {
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à une vidéo avec ${config.PREFIX}toaudio` });
  await sock.sendMessage(from, { audio: buf, mimetype: "audio/mp4", ptt: false });
}

async function tts(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}tts <texte>` });
  const url  = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=fr&client=tw-ob`;
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" });
    await sock.sendMessage(from, { audio: Buffer.from(res.data), mimetype: "audio/mpeg", ptt: true });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur TTS." });
  }
}

async function ttp(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}ttp <texte>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/maker/ttp?text=${encodeURIComponent(text)}`, { responseType: "arraybuffer" });
    await sock.sendMessage(from, { sticker: Buffer.from(res.data) });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur TTP." });
  }
}

async function attp(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}attp <texte>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/maker/attp?text=${encodeURIComponent(text)}`, { responseType: "arraybuffer" });
    await sock.sendMessage(from, { sticker: Buffer.from(res.data) });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur ATTP." });
  }
}

async function url(sock, msg, from) {
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à un média avec ${config.PREFIX}url` });
  await sock.sendMessage(from, { text: "⚠️ Upload de fichier non disponible sans serveur de stockage configuré." });
}

async function write(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}write <texte>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/maker/write?text=${encodeURIComponent(text)}`, { responseType: "arraybuffer" });
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption: "✍️ " + text });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur write." });
  }
}

async function circle(sock, msg, from) {
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à une image avec ${config.PREFIX}circle` });
  try {
    const sharp = require("sharp");
    const img   = sharp(buf);
    const meta  = await img.metadata();
    const size  = Math.min(meta.width, meta.height);
    const mask  = Buffer.from(`<svg><circle cx="${size/2}" cy="${size/2}" r="${size/2}"/></svg>`);
    const out   = await img.resize(size, size).composite([{input: mask, blend:"dest-in"}]).png().toBuffer();
    await sock.sendMessage(from, { image: out, caption: "⭕ Image circulaire" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur circle." });
  }
}

async function crop(sock, msg, from) {
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à une image avec ${config.PREFIX}crop` });
  try {
    const sharp = require("sharp");
    const out   = await sharp(buf).resize(512, 512, { fit:"cover" }).toBuffer();
    await sock.sendMessage(from, { image: out, caption: "✂️ Image rognée (512x512)" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur crop." });
  }
}

async function remini(sock, msg, from) {
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à une image avec ${config.PREFIX}remini` });
  await sock.sendMessage(from, { text: "⚠️ Remini nécessite une clé API tierce. Fonctionnalité à configurer." });
}

async function round(sock, msg, from) { return circle(sock, msg, from); }

async function fusion(sock, msg, from) {
  await sock.sendMessage(from, { text: "⚠️ Fusion nécessite 2 images. Réponds à une image et mentionne l'autre URL avec .fusion <url>" });
}

async function quotely(sock, msg, from) {
  await sock.sendMessage(from, { text: "⚠️ Quotely : génère un sticker de message cité. Réponds à un message avec .quotely" });
}

async function emix(sock, msg, from, args) {
  const emojis = args.slice(0,2);
  if (emojis.length < 2) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}emix 😀 🔥` });
  try {
    const e1 = encodeURIComponent(emojis[0]), e2 = encodeURIComponent(emojis[1]);
    const res = await axios.get(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCik&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${e1}_${e2}`, { responseType:"json" });
    const url  = res.data?.results?.[0]?.media_formats?.png_transparent?.url;
    if (!url) throw new Error();
    const img = await axios.get(url, { responseType:"arraybuffer" });
    await sock.sendMessage(from, { sticker: Buffer.from(img.data) });
  } catch {
    await sock.sendMessage(from, { text: "❌ Combinaison d'emojis introuvable." });
  }
}

async function take(sock, msg, from, args) {
  const name = args[0] || "OVL-MD";
  const author = args[1] || config.AUTHOR;
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à un sticker avec ${config.PREFIX}take <nom> <auteur>` });
  await sock.sendMessage(from, {
    sticker: buf,
    // Baileys permet de passer des métadonnées sticker
  });
  await sock.sendMessage(from, { text: `✅ Sticker volé : *${name}* par *${author}*` });
}

async function stickertovideo(sock, msg, from) {
  const quoted = getQuoted(msg);
  if (!quoted?.stickerMessage)
    return sock.sendMessage(from, { text: `❌ Réponds à un sticker animé avec ${config.PREFIX}stickertovideo` });
  const buf = await sock.downloadMediaMessage({ message: quoted });
  await sock.sendMessage(from, { video: buf, mimetype: "video/mp4", caption: "🎬 Sticker → Vidéo" });
}

async function tovideo(sock, msg, from) {
  const buf = await getMediaBuffer(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à un GIF/image avec ${config.PREFIX}tovideo` });
  await sock.sendMessage(from, { video: buf, mimetype:"video/mp4", caption:"🎬 Converti en vidéo" });
}

module.exports = {
  sticker, toimage, toaudio, tts, ttp, attp, url, write,
  circle, crop, remini, round, fusion, quotely, emix,
  take, stickertovideo, tovideo,
};
