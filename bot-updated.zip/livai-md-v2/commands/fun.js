// ╭──⟪ FUN ⟫──╮
const axios  = require("axios");
const config = require("../config");
const { getMentioned, getSender } = require("../lib/utils");

async function blague(sock, msg, from) {
  const jokes = [
    "Pourquoi les plongeurs plongent-ils en arrière ?\nParce que sinon ils tomberaient dans le bateau ! 😂",
    "C'est l'histoire d'un homme qui rentre chez lui… Il est rentré. 😐",
    "Qu'est-ce qu'un canif ? Un petit fien ! 🐕",
    "Pourquoi les informaticiens confondent Noël et Halloween ?\nOct 31 = Dec 25 🎃🎄",
    "Un homme dit à un autre : \"T'as vu mon chien ? Il a perdu une patte.\"\nL'autre répond : \"Appelle-le, il va venir en boitant !\" 🐾",
  ];
  await sock.sendMessage(from, { text: `😂 *Blague*\n\n${jokes[Math.floor(Math.random()*jokes.length)]}` });
}

async function citation(sock, msg, from) {
  try {
    const res = await axios.get("https://api.quotable.io/random");
    await sock.sendMessage(from, { text: `💬 *Citation*\n\n_"${res.data.content}"_\n— *${res.data.author}*` });
  } catch {
    await sock.sendMessage(from, { text: `💬 *Citation*\n\n_"Le succès c'est tomber sept fois, se relever huit."_\n— *Proverbe japonais*` });
  }
}

async function ship(sock, msg, from, args) {
  const m = getMentioned(msg);
  const sender = getSender(msg).split("@")[0];
  const target = m[0] ? m[0].split("@")[0] : args[0];
  if (!target) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}ship @quelquun` });
  const pct = Math.floor(Math.random() * 101);
  const bar = "█".repeat(Math.floor(pct/10)) + "░".repeat(10-Math.floor(pct/10));
  await sock.sendMessage(from, {
    text: `💞 *Ship Meter*\n\n+${sender} 💕 +${target}\n\n${bar} *${pct}%*\n\n${pct>=80?"❤️ Amour fou !":pct>=50?"💛 Bien assorti·es":"💔 Pas vraiment..."}`
  });
}

async function couplepp(sock, msg, from) {
  await sock.sendMessage(from, { text: "💑 *Couple PP* — Mentionne deux personnes : .couplepp @p1 @p2" });
}

async function fake(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}fake <texte>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/maker/fake?text=${encodeURIComponent(text)}`, { responseType:"arraybuffer" });
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption: "📱 Faux message" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur fake." });
  }
}

async function fancy(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}fancy <texte>` });
  const fancyMap = "abcdefghijklmnopqrstuvwxyz";
  const fancyOut = "𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃";
  const out = text.toLowerCase().split("").map(c => {
    const i = fancyMap.indexOf(c);
    return i >= 0 ? fancyOut[i] : c;
  }).join("");
  await sock.sendMessage(from, { text: `✨ *Fancy*\n\n${out}` });
}

async function fliptext(sock, msg, from, args) {
  const text = args.join(" ");
  const flip = { a:"ɐ",b:"q",c:"ɔ",d:"p",e:"ǝ",f:"ɟ",g:"ƃ",h:"ɥ",i:"ᴉ",j:"ɾ",k:"ʞ",l:"l",m:"ɯ",n:"u",o:"o",p:"d",q:"b",r:"ɹ",s:"s",t:"ʇ",u:"n",v:"ʌ",w:"ʍ",x:"x",y:"ʎ",z:"z" };
  const out = text.toLowerCase().split("").map(c => flip[c]||c).reverse().join("");
  await sock.sendMessage(from, { text: `🔄 *Flipped*\n\n${out}` });
}

async function readmore(sock, msg, from, args) {
  const text = args.join(" ") || "Texte caché...";
  const hidden = "\u200B".repeat(4000);
  await sock.sendMessage(from, { text: `${text}${hidden}\n📖 *[voir plus...]*` });
}

async function profile(sock, msg, from) {
  const sender = getSender(msg);
  try {
    const pp = await sock.profilePictureUrl(sender, "image");
    const name = msg.pushName || sender.split("@")[0];
    await sock.sendMessage(from, {
      image: { url: pp },
      caption: `👤 *Profil de ${name}*\n📱 Numéro : +${sender.split("@")[0]}`
    });
  } catch {
    await sock.sendMessage(from, { text: "❌ Impossible d'afficher le profil." });
  }
}

async function rank(sock, msg, from) {
  await sock.sendMessage(from, { text: "🏆 *Rank* — Système de rang en cours de développement." });
}

async function toprank(sock, msg, from) {
  await sock.sendMessage(from, { text: "🏅 *Top Rank* — Classement global en cours de développement." });
}

module.exports = { blague, citation, ship, couplepp, fake, fancy, fliptext, readmore, profile, rank, toprank };
