// ╭──⟪ OWNER EXTRA ⟫──╮
// Commandes avancées réservées au owner
const fs     = require("fs-extra");
const path   = require("path");
const config = require("../config");
const store  = require("../lib/store");
const { isOwner, getSender, getMentioned, getQuoted } = require("../lib/utils");

function ownerOnly(fn) {
  return async (sock, msg, from, args) => {
    if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
    return fn(sock, msg, from, args);
  };
}

// ── Sticker Commands personnalisés ────────────────────────
const STICK_FILE = path.join(__dirname, "../data/sticker_cmds.json");
function loadStick() { return fs.existsSync(STICK_FILE) ? fs.readJsonSync(STICK_FILE) : {}; }
function saveStick(d) { fs.writeJsonSync(STICK_FILE, d, { spaces:2 }); }

const addstickercmd = ownerOnly(async (sock, msg, from, args) => {
  const name = args[0];
  const q    = getQuoted(msg);
  if (!name || !q?.stickerMessage)
    return sock.sendMessage(from, { text: `❌ Réponds à un sticker avec ${config.PREFIX}addstickercmd <nom>` });
  const buf  = await sock.downloadMediaMessage({ message: q });
  const d    = loadStick();
  d[name]    = buf.toString("base64");
  saveStick(d);
  await sock.sendMessage(from, { text: `✅ Commande sticker *${config.PREFIX}${name}* ajoutée !` });
});

const delstickercmd = ownerOnly(async (sock, msg, from, args) => {
  const name = args[0];
  if (!name) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}delstickercmd <nom>` });
  const d = loadStick();
  if (!d[name]) return sock.sendMessage(from, { text: `❌ Commande *${name}* introuvable.` });
  delete d[name];
  saveStick(d);
  await sock.sendMessage(from, { text: `✅ Commande sticker *${name}* supprimée.` });
});

const getstickercmd = ownerOnly(async (sock, msg, from) => {
  const d    = loadStick();
  const keys = Object.keys(d);
  if (!keys.length) return sock.sendMessage(from, { text: "ℹ️ Aucune commande sticker." });
  await sock.sendMessage(from, { text: `🎭 *Sticker Commands* (${keys.length})\n\n${keys.map(k=>`• ${config.PREFIX}${k}`).join("\n")}` });
});

// Handler à appeler depuis index.js pour les sticker cmds dynamiques
async function handleStickerCmd(sock, msg, from, command) {
  const d = loadStick();
  if (!d[command]) return false;
  const buf = Buffer.from(d[command], "base64");
  await sock.sendMessage(from, { sticker: buf });
  return true;
}

// ── Commandes privées/publiques custom ────────────────────
const PRIV_FILE = path.join(__dirname, "../data/private_cmds.json");
const PUB_FILE  = path.join(__dirname, "../data/public_cmds.json");
function loadPriv() { return fs.existsSync(PRIV_FILE) ? fs.readJsonSync(PRIV_FILE) : {}; }
function loadPub()  { return fs.existsSync(PUB_FILE)  ? fs.readJsonSync(PUB_FILE)  : {}; }
function savePriv(d){ fs.writeJsonSync(PRIV_FILE, d, { spaces:2 }); }
function savePub(d) { fs.writeJsonSync(PUB_FILE,  d, { spaces:2 }); }

const setprivate_cmd = ownerOnly(async (sock, msg, from, args) => {
  const name = args[0], response = args.slice(1).join(" ");
  if (!name || !response) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}setprivate_cmd <nom> <réponse>` });
  const d = loadPriv(); d[name] = response; savePriv(d);
  await sock.sendMessage(from, { text: `✅ Commande privée *${config.PREFIX}${name}* créée.` });
});

const delprivate_cmd = ownerOnly(async (sock, msg, from, args) => {
  const name = args[0];
  if (!name) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}delprivate_cmd <nom>` });
  const d = loadPriv(); delete d[name]; savePriv(d);
  await sock.sendMessage(from, { text: `✅ Commande privée *${name}* supprimée.` });
});

const listprivate_cmd = ownerOnly(async (sock, msg, from) => {
  const d = loadPriv(), keys = Object.keys(d);
  await sock.sendMessage(from, { text: `🔒 *Commandes privées* (${keys.length})\n\n${keys.map(k=>`• ${config.PREFIX}${k} → ${d[k]}`).join("\n") || "Aucune."}` });
});

const setpublic_cmd = ownerOnly(async (sock, msg, from, args) => {
  const name = args[0], response = args.slice(1).join(" ");
  if (!name || !response) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}setpublic_cmd <nom> <réponse>` });
  const d = loadPub(); d[name] = response; savePub(d);
  await sock.sendMessage(from, { text: `✅ Commande publique *${config.PREFIX}${name}* créée.` });
});

const delpublic_cmd = ownerOnly(async (sock, msg, from, args) => {
  const name = args[0];
  if (!name) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}delpublic_cmd <nom>` });
  const d = loadPub(); delete d[name]; savePub(d);
  await sock.sendMessage(from, { text: `✅ Commande publique *${name}* supprimée.` });
});

const listpublic_cmd = ownerOnly(async (sock, msg, from) => {
  const d = loadPub(), keys = Object.keys(d);
  await sock.sendMessage(from, { text: `🌍 *Commandes publiques* (${keys.length})\n\n${keys.map(k=>`• ${config.PREFIX}${k} → ${d[k]}`).join("\n") || "Aucune."}` });
});

// Handler pour commandes custom (privées + publiques)
async function handleCustomCmd(sock, msg, from, command, isOwnerUser) {
  const pub  = loadPub();
  const priv = loadPriv();
  if (pub[command]) {
    await sock.sendMessage(from, { text: pub[command] });
    return true;
  }
  if (priv[command] && isOwnerUser) {
    await sock.sendMessage(from, { text: priv[command] });
    return true;
  }
  return false;
}

// ── Session / Connexion ───────────────────────────────────
const connect_session = ownerOnly(async (sock, msg, from, args) => {
  const code = args[0];
  if (!code) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}connect_session <code>` });
  await sock.sendMessage(from, { text: `🔗 Connexion avec le code session : \`${code}\`\nRelance le bot pour que la session soit prise en compte.` });
});

const fetch_sc = ownerOnly(async (sock, msg, from) => {
  const sessionDir = config.SESSION_DIR;
  try {
    const files = fs.readdirSync(sessionDir);
    await sock.sendMessage(from, { text: `📁 *Session Files* (${files.length})\n\n${files.join("\n")}` });
  } catch {
    await sock.sendMessage(from, { text: "❌ Impossible de lire le dossier de session." });
  }
});

// ── Mentions ──────────────────────────────────────────────
const MENTION_FILE = path.join(__dirname, "../data/mentions.json");
function loadMention() { return fs.existsSync(MENTION_FILE) ? fs.readJsonSync(MENTION_FILE) : { jids: [], text: "👋" }; }
function saveMention(d){ fs.writeJsonSync(MENTION_FILE, d, { spaces:2 }); }

const setmention = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  const text    = args.filter(a => !a.startsWith("@")).join(" ") || "👋";
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}setmention @quelquun <texte>` });
  saveMention({ jids: targets, text });
  await sock.sendMessage(from, { text: `✅ Mention auto définie pour ${targets.length} personne(s).` });
});

const getmention = ownerOnly(async (sock, msg, from) => {
  const d = loadMention();
  await sock.sendMessage(from, {
    text: `📢 *Mention auto*\n\nPersonnes : ${d.jids.map(j=>"@"+j.split("@")[0]).join(", ")||"Aucune"}\nTexte : _${d.text}_`
  });
});

const delmention = ownerOnly(async (sock, msg, from) => {
  saveMention({ jids: [], text: "" });
  await sock.sendMessage(from, { text: "✅ Mention auto supprimée." });
});

// ── React message ─────────────────────────────────────────
const react_msg = ownerOnly(async (sock, msg, from, args) => {
  const emoji = args[0] || "❤️";
  const q     = getQuoted(msg);
  if (!q) return sock.sendMessage(from, { text: `❌ Réponds à un message avec ${config.PREFIX}react_msg <emoji>` });
  const key = msg.message?.extendedTextMessage?.contextInfo;
  if (!key?.stanzaId) return sock.sendMessage(from, { text: "❌ Impossible de trouver le message." });
  await sock.sendMessage(from, {
    react: { text: emoji, key: { remoteJid: from, id: key.stanzaId, participant: key.participant } }
  });
});

// ── Lecture message ───────────────────────────────────────
const lecture_msg = ownerOnly(async (sock, msg, from) => {
  const q = getQuoted(msg);
  if (!q) return sock.sendMessage(from, { text: `❌ Réponds à un message avec ${config.PREFIX}lecture_msg` });
  const key = msg.message?.extendedTextMessage?.contextInfo;
  if (key?.stanzaId) {
    await sock.readMessages([{ remoteJid: from, id: key.stanzaId, participant: key.participant }]);
    await sock.sendMessage(from, { text: "✅ Message marqué comme lu." });
  }
});

// ── Plugin system ─────────────────────────────────────────
const PG_FILE = path.join(__dirname, "../data/plugins.json");
function loadPlugins() { return fs.existsSync(PG_FILE) ? fs.readJsonSync(PG_FILE) : []; }
function savePlugins(d){ fs.writeJsonSync(PG_FILE, d, { spaces:2 }); }

const pginstall = ownerOnly(async (sock, msg, from, args) => {
  const url = args[0];
  if (!url) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}pginstall <url_plugin>` });
  const plugins = loadPlugins();
  if (plugins.includes(url)) return sock.sendMessage(from, { text: "ℹ️ Plugin déjà installé." });
  plugins.push(url);
  savePlugins(plugins);
  await sock.sendMessage(from, { text: `✅ Plugin ajouté : \`${url}\`\nRedémarre le bot pour l'activer.` });
});

const pgremove = ownerOnly(async (sock, msg, from, args) => {
  const url = args[0];
  if (!url) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}pgremove <url_plugin>` });
  const plugins = loadPlugins().filter(p => p !== url);
  savePlugins(plugins);
  await sock.sendMessage(from, { text: `✅ Plugin supprimé.` });
});

const pglist = ownerOnly(async (sock, msg, from) => {
  const plugins = loadPlugins();
  await sock.sendMessage(from, {
    text: `📦 *Plugins installés* (${plugins.length})\n\n${plugins.map((p,i)=>`${i+1}. ${p}`).join("\n") || "Aucun plugin."}`
  });
});

// ── Levelup ───────────────────────────────────────────────
const LEVEL_FILE = path.join(__dirname, "../data/levels.json");
function loadLevels() { return fs.existsSync(LEVEL_FILE) ? fs.readJsonSync(LEVEL_FILE) : {}; }
function saveLevels(d){ fs.writeJsonSync(LEVEL_FILE, d, { spaces:2 }); }

const levelup = ownerOnly(async (sock, msg, from, args) => {
  const targets = getMentioned(msg);
  const amount  = parseInt(args.find(a=>!isNaN(a))) || 1;
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}levelup @quelquun <niveaux>` });
  const d = loadLevels();
  for (const t of targets) {
    d[t] = (d[t] || 0) + amount;
  }
  saveLevels(d);
  await sock.sendMessage(from, {
    text: `⬆️ ${targets.map(t=>`@${t.split("@")[0]}`).join(", ")} → Niveau *${d[targets[0]]}*`,
    mentions: targets
  });
});

// ── Only admins mode ──────────────────────────────────────
const onlyadmins = ownerOnly(async (sock, msg, from) => {
  const active = store.toggle("onlyadmins", from);
  await sock.sendMessage(from, { text: `🔐 Mode only admins : *${active ? "✅ Activé" : "❌ Désactivé"}*` });
});

module.exports = {
  addstickercmd, delstickercmd, getstickercmd,
  handleStickerCmd, handleCustomCmd,
  setprivate_cmd, delprivate_cmd, listprivate_cmd,
  setpublic_cmd, delpublic_cmd, listpublic_cmd,
  connect_session, fetch_sc,
  setmention, getmention, delmention,
  react_msg, lecture_msg,
  pginstall, pgremove, pglist,
  levelup, onlyadmins,
};
