const { getUptime, getDateTime } = require("../lib/utils");
const config = require("../config");

const MENU = `
╭──《 🤖 ${config.BOT_NAME} 》──╮
├ ߷ PRÉFIXE       : ${config.PREFIX}
├ ߷ OWNER         : ${config.OWNER_NAME}
├ ߷ VERSION       : ${config.VERSION}
├ ߷ DÉVELOPPEUR   : ${config.AUTHOR}
├ ߷ PLATEFORME    : ${config.PLATFORM}
├ ߷ UPTIME        : {uptime}
├ ߷ DATE          : {date}
├ ߷ HEURE         : {time}
╰──────────────────╯

╭──⟪ CONFIDENTIALITÉ ⟫──╮
├ ߷ getprivacy | groupadd | lastseen
├ ߷ mypp | mystatus | online
├ ߷ presence | read | setbio
╰──────────────────╯

╭──⟪ CONVERSION ⟫──╮
├ ߷ attp | circle | crop | emix
├ ߷ fusion | quotely | remini | round
├ ߷ sticker | stickertovideo | take
├ ߷ toaudio | toimage | tovideo
├ ߷ ttp | tts | url | write
╰──────────────────╯

╭──⟪ FUN ⟫──╮
├ ߷ blague | citation | couplepp
├ ߷ fake | fancy | fliptext
├ ߷ profile | rank | readmore
├ ߷ ship | toprank
╰──────────────────╯

╭──⟪ FX AUDIO ⟫──╮
├ ߷ alien | bass | blown | buzz | cave
├ ߷ chipmunk | chorus | compressor
├ ߷ dark | deep | distortion | dizzy
├ ߷ earrape | echo | fast | fat
├ ߷ flanger | ghost | haunting | invert
├ ߷ lofi | mono | muted | nightcore
├ ߷ panorama | phaser | radio | reverb
├ ߷ reverse | robot | slow | smooth
├ ߷ space | squirrel | surround
├ ߷ telephone | tremolo | underwater
├ ߷ vibrato | vintage
╰──────────────────╯

╭──⟪ GROUPE ⟫──╮
├ ߷ acceptall | antibot | antidemote
├ ߷ antilink | antimentiongc | antipromote
├ ߷ antispam | antitag | ckick | close
├ ߷ demote | demotealert | gccreate | gdesc
├ ߷ getpp | ginfo | gname | goodbye
├ ߷ join | kick | kickall | leave | link
├ ߷ lock | open | poll | poll2 | promote
├ ߷ promotealert | rejectall | removepp
├ ߷ revoke | tag | tagadmin | tagall
├ ߷ unlock | updatepp | vcf | warn | welcome
╰──────────────────╯

╭──⟪ IA ⟫──╮
├ ߷ blackbox | claude | copilot
├ ߷ dalle | gemini | gpt | llama
╰──────────────────╯

╭──⟪ IMAGE EDITS ⟫──╮
├ ߷ affect | beautiful | blur | circle1
├ ߷ colorfy | darkness | delete_image
├ ߷ facepalmm | greyscale | jail
├ ߷ jokeoverhead | pixelate | rainbow
├ ߷ rip | sepia | threshold | trash | trigger
├ ߷ wanted | wasted
╰──────────────────╯

╭──⟪ LOGO ⟫──╮
├ ߷ avengers | blackpink | cloud | cubic
├ ߷ deadpool | dragonball | football
├ ߷ futuris | galaxy | glass | gold1-5
├ ߷ graffiti1-3 | hacker | metal
├ ߷ naruto | neon1-3 | onepiece | paint
├ ߷ plasma | rain | sand | sci_fi
├ ߷ space | steel | summery | thor
├ ߷ thunder | typography | vintage
├ ߷ watercolor | wood
╰──────────────────╯

╭──⟪ OUTILS ⟫──╮
├ ߷ allmenu | capture | description
├ ߷ developpeur | gitclone | menu
├ ߷ obfuscate | owner | pair | ping | qr
├ ߷ repo | support | system_status
├ ߷ tempinbox | tempmail | test | theme
├ ߷ tovv | translate | uptime | vv | vv2
╰──────────────────╯

╭──⟪ OVL-ECONOMY ⟫──╮
├ ߷ bonus | capacite | depot | don
├ ߷ myecon | pari | resetaccount
├ ߷ retrait | slot | transfer | vol
╰──────────────────╯

╭──⟪ OVL-GAMES ⟫──╮
├ ߷ anime-quizz | dmots | tictactoe | wcg
╰──────────────────╯

╭──⟪ OWNER ⟫──╮
├ ߷ (réservé au propriétaire du bot)
╰──────────────────╯

╭──⟪ RÉACTION ⟫──╮
├ ߷ assommer | awoo | caliner | clin_doeil
├ ߷ coup_de_pied | croquer | danser
├ ߷ embeter | embrasser | enlacer | gene
├ ߷ gifler | heureux | highfive | lancer
├ ߷ lecher | mordre | pleurer | pousser
├ ߷ rougir | saluer | sauter | sourire
├ ߷ tapoter | tenir_main | tuer
╰──────────────────╯

╭──⟪ SEARCH ⟫──╮
├ ߷ anime | github | google | imdb | img
├ ߷ lyrics | meteo | shazam
├ ߷ stickersearch | wiki
╰──────────────────╯

╭──⟪ STATUS ⟫──╮
├ ߷ dl_status | lecture_status
├ ߷ likestatus | save | sendme
╰──────────────────╯

╭──⟪ SYSTÈME ⟫──╮
├ ߷ checkupdate | delvar | getvar
├ ߷ setvar | update
╰──────────────────╯

╭──⟪ TÉLÉCHARGEMENT ⟫──╮
├ ߷ app | fbdl | igdl | song | tiktok
├ ߷ tiktokaudio | tiktokimage | twitterdl
├ ߷ video | yta | ytv
╰──────────────────╯

> ©️2025 ${config.BOT_NAME} by *${config.AUTHOR}*`;

module.exports = async function(sock, msg, from) {
  const { date, time } = getDateTime();
  const text = MENU
    .replace("{uptime}", getUptime())
    .replace("{date}", date)
    .replace("{time}", time);

  try {
    await sock.sendMessage(from, { image: { url: config.BANNER_URL }, caption: text });
  } catch {
    await sock.sendMessage(from, { text });
  }
};
