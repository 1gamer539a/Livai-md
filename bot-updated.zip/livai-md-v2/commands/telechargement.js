// ╭──⟪ TÉLÉCHARGEMENT ⟫──╮
const axios  = require("axios");
const config = require("../config");

async function song(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}song <titre>` });
  await sock.sendMessage(from, { text: `🎵 Recherche de *${q}*...` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/ytmp3?url=https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`);
    if (res.data?.url) {
      const buf = await axios.get(res.data.url, { responseType:"arraybuffer" });
      await sock.sendMessage(from, { audio: Buffer.from(buf.data), mimetype:"audio/mpeg", fileName:`${q}.mp3` });
    } else throw new Error();
  } catch {
    await sock.sendMessage(from, { text: `❌ Impossible de télécharger *${q}*.\nEssaie : ${config.PREFIX}yta <url youtube>` });
  }
}

async function yta(sock, msg, from, args) {
  const url = args[0];
  if (!url) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}yta <url youtube>` });
  await sock.sendMessage(from, { text: "⏳ Téléchargement audio YouTube..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/ytmp3?url=${encodeURIComponent(url)}`);
    if (!res.data?.url) throw new Error();
    const buf = await axios.get(res.data.url, { responseType:"arraybuffer" });
    await sock.sendMessage(from, { audio: Buffer.from(buf.data), mimetype:"audio/mpeg", fileName:"audio.mp3" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur téléchargement YouTube Audio." });
  }
}

async function ytv(sock, msg, from, args) {
  const url = args[0];
  if (!url) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}ytv <url youtube>` });
  await sock.sendMessage(from, { text: "⏳ Téléchargement vidéo YouTube..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(url)}`);
    if (!res.data?.url) throw new Error();
    await sock.sendMessage(from, { video: { url: res.data.url }, mimetype:"video/mp4", caption:"🎬 Vidéo YouTube" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur téléchargement YouTube Vidéo." });
  }
}

async function tiktok(sock, msg, from, args) {
  const url = args[0];
  if (!url?.includes("tiktok")) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}tiktok <url tiktok>` });
  await sock.sendMessage(from, { text: "⏳ Téléchargement TikTok..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`);
    const dl  = res.data?.data?.play || res.data?.data?.video;
    if (!dl) throw new Error();
    await sock.sendMessage(from, { video: { url: dl }, mimetype:"video/mp4", caption:"🎵 TikTok" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur téléchargement TikTok." });
  }
}

async function tiktokaudio(sock, msg, from, args) {
  const url = args[0];
  if (!url?.includes("tiktok")) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}tiktokaudio <url>` });
  await sock.sendMessage(from, { text: "⏳ Extraction audio TikTok..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`);
    const dl  = res.data?.data?.music;
    if (!dl) throw new Error();
    const buf = await axios.get(dl, { responseType:"arraybuffer" });
    await sock.sendMessage(from, { audio: Buffer.from(buf.data), mimetype:"audio/mpeg" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur extraction audio TikTok." });
  }
}

async function tiktokimage(sock, msg, from, args) {
  const url = args[0];
  if (!url?.includes("tiktok")) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}tiktokimage <url>` });
  await sock.sendMessage(from, { text: "⏳ Extraction image TikTok..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`);
    const img = res.data?.data?.cover;
    if (!img) throw new Error();
    await sock.sendMessage(from, { image: { url: img }, caption: "🖼 TikTok Cover" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur extraction image TikTok." });
  }
}

async function igdl(sock, msg, from, args) {
  const url = args[0];
  if (!url?.includes("instagram")) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}igdl <url instagram>` });
  await sock.sendMessage(from, { text: "⏳ Téléchargement Instagram..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/ig?url=${encodeURIComponent(url)}`);
    const dl  = res.data?.data?.[0]?.url;
    if (!dl) throw new Error();
    await sock.sendMessage(from, { video: { url: dl }, mimetype:"video/mp4", caption:"📸 Instagram" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur téléchargement Instagram." });
  }
}

async function fbdl(sock, msg, from, args) {
  const url = args[0];
  if (!url?.includes("facebook")) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}fbdl <url facebook>` });
  await sock.sendMessage(from, { text: "⏳ Téléchargement Facebook..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/fb?url=${encodeURIComponent(url)}`);
    const dl  = res.data?.data?.url;
    if (!dl) throw new Error();
    await sock.sendMessage(from, { video: { url: dl }, mimetype:"video/mp4", caption:"📘 Facebook" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur téléchargement Facebook." });
  }
}

async function twitterdl(sock, msg, from, args) {
  const url = args[0];
  if (!url?.includes("twitter")&&!url?.includes("x.com")) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}twitterdl <url>` });
  await sock.sendMessage(from, { text: "⏳ Téléchargement Twitter/X..." });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/d/twitter?url=${encodeURIComponent(url)}`);
    const dl  = res.data?.data?.url;
    if (!dl) throw new Error();
    await sock.sendMessage(from, { video: { url: dl }, mimetype:"video/mp4", caption:"🐦 Twitter/X" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur téléchargement Twitter." });
  }
}

async function video(sock, msg, from, args) {
  const url = args[0];
  if (!url) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}video <url>` });
  await sock.sendMessage(from, { text: "⏳ Téléchargement vidéo..." });
  try {
    await sock.sendMessage(from, { video: { url }, mimetype:"video/mp4", caption:"🎬 Vidéo" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Impossible de télécharger cette vidéo." });
  }
}

async function app(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}app <nom app>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/s/playstore?q=${encodeURIComponent(q)}`);
    const a   = res.data?.data?.[0];
    if (!a) throw new Error();
    await sock.sendMessage(from, {
      text: `📱 *${a.title}*\n\n⭐ ${a.score} | 💾 ${a.size}\n📖 ${a.description?.slice(0,200)}\n🔗 ${a.url}`
    });
  } catch {
    await sock.sendMessage(from, { text: `❌ App introuvable sur le Play Store.` });
  }
}

module.exports = { song, yta, ytv, tiktok, tiktokaudio, tiktokimage, igdl, fbdl, twitterdl, video, app };
