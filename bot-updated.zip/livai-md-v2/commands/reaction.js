// ╭──⟪ RÉACTION ⟫──╮
const axios  = require("axios");
const { getSender, getMentioned } = require("../lib/utils");

const REACTIONS = {
  assommer:     { api:"waifu.pics/sfw/kick",     emoji:"👊", fr:"a assommé" },
  awoo:         { api:"waifu.pics/sfw/waifu",    emoji:"🐺", fr:"fait awoo" },
  caliner:      { api:"waifu.pics/sfw/cuddle",   emoji:"🤗", fr:"câline" },
  clin_doeil:   { api:"waifu.pics/sfw/wink",     emoji:"😉", fr:"fait un clin d'œil à" },
  coup_de_pied: { api:"waifu.pics/sfw/kick",     emoji:"🦶", fr:"donne un coup de pied à" },
  croquer:      { api:"waifu.pics/sfw/bite",     emoji:"😬", fr:"croque" },
  danser:       { api:"waifu.pics/sfw/dance",    emoji:"💃", fr:"danse avec" },
  embeter:      { api:"waifu.pics/sfw/poke",     emoji:"😜", fr:"embête" },
  embrasser:    { api:"waifu.pics/sfw/kiss",     emoji:"💋", fr:"embrasse" },
  enlacer:      { api:"waifu.pics/sfw/hug",      emoji:"🫂", fr:"enlace" },
  gene:         { api:"waifu.pics/sfw/blush",    emoji:"😳", fr:"gêne" },
  gifler:       { api:"waifu.pics/sfw/slap",     emoji:"👋", fr:"gifle" },
  heureux:      { api:"waifu.pics/sfw/happy",    emoji:"😊", fr:"est heureux/se avec" },
  highfive:     { api:"waifu.pics/sfw/highfive", emoji:"🙌", fr:"tape dans la main de" },
  lancer:       { api:"waifu.pics/sfw/throw",    emoji:"🤾", fr:"lance quelque chose à" },
  lecher:       { api:"waifu.pics/sfw/lick",     emoji:"👅", fr:"lèche" },
  mordre:       { api:"waifu.pics/sfw/bite",     emoji:"🦷", fr:"mord" },
  pleurer:      { api:"waifu.pics/sfw/cry",      emoji:"😭", fr:"pleure avec" },
  pousser:      { api:"waifu.pics/sfw/poke",     emoji:"👉", fr:"pousse" },
  rougir:       { api:"waifu.pics/sfw/blush",    emoji:"😊", fr:"rougit devant" },
  saluer:       { api:"waifu.pics/sfw/wave",     emoji:"👋", fr:"salue" },
  sauter:       { api:"waifu.pics/sfw/run",      emoji:"🏃", fr:"saute sur" },
  sourire:      { api:"waifu.pics/sfw/smile",    emoji:"😊", fr:"sourit à" },
  sourire_fier: { api:"waifu.pics/sfw/smug",     emoji:"😏", fr:"sourit fièrement à" },
  tapoter:      { api:"waifu.pics/sfw/pat",      emoji:"🫱", fr:"tapote la tête de" },
  tenir_main:   { api:"waifu.pics/sfw/handhold", emoji:"🤝", fr:"tient la main de" },
  tuer:         { api:"waifu.pics/sfw/kill",     emoji:"💀", fr:"tue" },
};

async function doReaction(sock, msg, from, name) {
  const r = REACTIONS[name];
  if (!r) return;
  const sender = (msg.pushName || getSender(msg).split("@")[0]);
  const targets = getMentioned(msg);
  const target  = targets.length ? `@${targets[0].split("@")[0]}` : "tout le monde";
  try {
    const res = await axios.get(`https://api.${r.api}`);
    const url  = res.data?.url;
    if (!url) throw new Error();
    await sock.sendMessage(from, {
      image: { url },
      caption: `${r.emoji} *${sender}* ${r.fr} *${target}*`,
      mentions: targets,
    });
  } catch {
    await sock.sendMessage(from, {
      text: `${r.emoji} *${sender}* ${r.fr} *${target}*`,
      mentions: targets,
    });
  }
}

const exports_ = {};
for (const name of Object.keys(REACTIONS)) {
  exports_[name] = (sock, msg, from) => doReaction(sock, msg, from, name);
}
module.exports = exports_;
