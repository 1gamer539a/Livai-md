// ╭──⟪ IA ⟫──╮
const axios  = require("axios");
const config = require("../config");

async function gpt(sock, msg, from, args) {
  const prompt = args.join(" ");
  if (!prompt) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}gpt <question>` });
  if (!config.OPENAI_KEY) return sock.sendMessage(from, { text: "⚠️ OPENAI_KEY non configurée dans config.js" });
  await sock.sendMessage(from, { text: "🤖 GPT réfléchit..." });
  try {
    const res = await axios.post("https://api.openai.com/v1/chat/completions", {
      model: "gpt-3.5-turbo",
      messages: [{ role:"user", content: prompt }],
      max_tokens: 1000,
    }, { headers: { Authorization: `Bearer ${config.OPENAI_KEY}` } });
    const reply = res.data.choices[0].message.content.trim();
    await sock.sendMessage(from, { text: `🤖 *GPT*\n\n${reply}` });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur GPT : ${e.message}` });
  }
}

async function gemini(sock, msg, from, args) {
  const prompt = args.join(" ");
  if (!prompt) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}gemini <question>` });
  if (!config.GEMINI_KEY) return sock.sendMessage(from, { text: "⚠️ GEMINI_KEY non configurée dans config.js" });
  await sock.sendMessage(from, { text: "💎 Gemini réfléchit..." });
  try {
    const res = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${config.GEMINI_KEY}`,
      { contents: [{ parts: [{ text: prompt }] }] }
    );
    const reply = res.data.candidates[0].content.parts[0].text;
    await sock.sendMessage(from, { text: `💎 *Gemini*\n\n${reply}` });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur Gemini : ${e.message}` });
  }
}

async function claude(sock, msg, from, args) {
  const prompt = args.join(" ");
  if (!prompt) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}claude <question>` });
  await sock.sendMessage(from, { text: "🧠 Claude réfléchit..." });
  try {
    const res = await axios.post("https://api.blackbox.ai/api/chat", {
      messages: [{ role:"user", content: prompt }],
      model: "claude-sonnet-4-5",
      stream: false,
    });
    const reply = res.data?.choices?.[0]?.message?.content || res.data?.response || "Pas de réponse.";
    await sock.sendMessage(from, { text: `🧠 *Claude*\n\n${reply}` });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur Claude : ${e.message}` });
  }
}

async function blackbox(sock, msg, from, args) {
  const prompt = args.join(" ");
  if (!prompt) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}blackbox <question>` });
  await sock.sendMessage(from, { text: "⬛ Blackbox réfléchit..." });
  try {
    const res = await axios.post("https://api.blackbox.ai/api/chat", {
      messages: [{ role:"user", content: prompt }],
      stream: false,
    });
    const reply = res.data?.choices?.[0]?.message?.content || "Pas de réponse.";
    await sock.sendMessage(from, { text: `⬛ *Blackbox*\n\n${reply}` });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur Blackbox : ${e.message}` });
  }
}

async function copilot(sock, msg, from, args) {
  const prompt = args.join(" ");
  if (!prompt) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}copilot <question>` });
  await sock.sendMessage(from, { text: "🪁 Copilot réfléchit..." });
  try {
    const res = await axios.post("https://api.blackbox.ai/api/chat", {
      messages: [{ role:"user", content: prompt }],
      model: "copilot",
      stream: false,
    });
    const reply = res.data?.choices?.[0]?.message?.content || "Pas de réponse.";
    await sock.sendMessage(from, { text: `🪁 *Copilot*\n\n${reply}` });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur Copilot : ${e.message}` });
  }
}

async function llama(sock, msg, from, args) {
  const prompt = args.join(" ");
  if (!prompt) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}llama <question>` });
  await sock.sendMessage(from, { text: "🦙 Llama réfléchit..." });
  try {
    const res = await axios.post("https://api.blackbox.ai/api/chat", {
      messages: [{ role:"user", content: prompt }],
      model: "llama-3.1-8b",
      stream: false,
    });
    const reply = res.data?.choices?.[0]?.message?.content || "Pas de réponse.";
    await sock.sendMessage(from, { text: `🦙 *Llama*\n\n${reply}` });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur Llama : ${e.message}` });
  }
}

async function dalle(sock, msg, from, args) {
  const prompt = args.join(" ");
  if (!prompt) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}dalle <description image>` });
  if (!config.OPENAI_KEY) return sock.sendMessage(from, { text: "⚠️ OPENAI_KEY non configurée." });
  await sock.sendMessage(from, { text: "🎨 Génération d'image en cours..." });
  try {
    const res = await axios.post("https://api.openai.com/v1/images/generations", {
      prompt, n:1, size:"512x512",
    }, { headers: { Authorization: `Bearer ${config.OPENAI_KEY}` } });
    const url = res.data.data[0].url;
    await sock.sendMessage(from, { image: { url }, caption: `🎨 *DALL·E*\n_${prompt}_` });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur DALL·E : ${e.message}` });
  }
}

module.exports = { gpt, gemini, claude, blackbox, copilot, llama, dalle };
