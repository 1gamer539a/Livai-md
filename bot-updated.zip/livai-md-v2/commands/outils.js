// ╭──⟪ OUTILS ⟫──╮
const axios  = require("axios");
const config = require("../config");
const { getUptime, getDateTime, isOwner } = require("../lib/utils");

async function ping(sock, msg, from) {
  const t = Date.now();
  await sock.sendMessage(from, { text: "🏓 Pong !" });
  await sock.sendMessage(from, { text: `⚡ *Vitesse :* ${Date.now()-t}ms` });
}

async function uptime(sock, msg, from) {
  await sock.sendMessage(from, { text: `⏱ *Uptime :* ${getUptime()}` });
}

async function owner(sock, msg, from) {
  await sock.sendMessage(from, { text: `👑 *Owner :* ${config.OWNER_NAME}\n📱 Contact : wa.me/${config.OWNER_NUMBER}` });
}

async function developpeur(sock, msg, from) {
  await sock.sendMessage(from, { text: `💻 *Développeur :* ${config.AUTHOR}\n🤖 Bot : ${config.BOT_NAME} v${config.VERSION}` });
}

async function system_status(sock, msg, from) {
  const os  = require("os");
  const mem = process.memoryUsage();
  await sock.sendMessage(from, {
    text: `🖥 *Statut système*\n\n` +
      `• OS : ${os.type()} ${os.release()}\n` +
      `• CPU : ${os.cpus()[0]?.model||"N/A"}\n` +
      `• RAM totale : ${Math.round(os.totalmem()/1024/1024)} Mo\n` +
      `• RAM libre : ${Math.round(os.freemem()/1024/1024)} Mo\n` +
      `• RAM bot : ${Math.round(mem.heapUsed/1024/1024)} Mo\n` +
      `• Uptime : ${getUptime()}`
  });
}

async function translate(sock, msg, from, args) {
  const lang = args[0] || "fr";
  const text = args.slice(1).join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}translate <lang> <texte>\nEx: .translate en Bonjour` });
  try {
    const res = await axios.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(text)}`);
    const out  = res.data[0].map(x=>x[0]).join("");
    await sock.sendMessage(from, { text: `🌍 *Traduction (${lang})*\n\n${out}` });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur de traduction." });
  }
}

async function qr(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}qr <texte>` });
  const url  = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(text)}`;
  await sock.sendMessage(from, { image: { url }, caption: `📷 *QR Code*\n_${text}_` });
}

async function tempmail(sock, msg, from) {
  try {
    const res = await axios.get("https://api.guerrillamail.com/ajax.php?f=get_email_address");
    await sock.sendMessage(from, { text: `📧 *Email temporaire*\n\n\`${res.data.email_addr}\`\n\nValide 1h` });
  } catch {
    await sock.sendMessage(from, { text: "❌ Impossible de créer un email temporaire." });
  }
}

async function tempinbox(sock, msg, from, args) {
  const email = args[0];
  if (!email) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}tempinbox <email>` });
  await sock.sendMessage(from, { text: `📥 *Boîte de réception temporaire*\n\nEmail : ${email}\nVérification via guerrillamail.com` });
}

async function capture(sock, msg, from, args) {
  const url = args[0];
  if (!url) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}capture <url>` });
  try {
    const res = await axios.get(`https://api.apiflash.com/v1/urltoimage?access_key=free&url=${encodeURIComponent(url)}`, { responseType:"arraybuffer" });
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption: `📸 Capture de ${url}` });
  } catch {
    await sock.sendMessage(from, { text: "❌ Impossible de capturer la page." });
  }
}

async function repo(sock, msg, from) {
  await sock.sendMessage(from, { text: `📦 *Repo GitHub*\nhttps://github.com/TON_GITHUB/livai-md-v2` });
}

async function support(sock, msg, from) {
  await sock.sendMessage(from, { text: `📞 *Support*\nContacte le owner : wa.me/${config.OWNER_NUMBER}` });
}

async function pair(sock, msg, from, args) {
  await sock.sendMessage(from, { text: "🔗 Utilise la commande depuis le terminal pour obtenir un code de jumelage." });
}

async function test(sock, msg, from) {
  await sock.sendMessage(from, { text: `✅ Bot fonctionnel !\n⏱ Uptime : ${getUptime()}` });
}

async function tovv(sock, msg, from) {
  const { getQuoted } = require("../lib/utils");
  const q = getQuoted(msg);
  if (!q?.videoMessage) return sock.sendMessage(from, { text: "❌ Réponds à une vidéo." });
  const buf = await sock.downloadMediaMessage({ message: q });
  await sock.sendMessage(from, { video: buf, mimetype:"video/mp4", viewOnce: true, caption:"👁 View Once" });
}

async function vv(sock, msg, from) { return tovv(sock, msg, from); }

async function vv2(sock, msg, from) {
  const { getQuoted } = require("../lib/utils");
  const q = getQuoted(msg);
  if (!q?.imageMessage) return sock.sendMessage(from, { text: "❌ Réponds à une image." });
  const buf = await sock.downloadMediaMessage({ message: q });
  await sock.sendMessage(from, { image: buf, viewOnce: true, caption:"👁 View Once" });
}

async function obfuscate(sock, msg, from, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}obfuscate <texte>` });
  const out  = Buffer.from(text).toString("base64");
  await sock.sendMessage(from, { text: `🔐 *Obfusqué*\n\`${out}\`` });
}

async function description(sock, msg, from) {
  await sock.sendMessage(from, {
    text: `📖 *${config.BOT_NAME}*\n\n_Bot WhatsApp Multi-Device avec ${Object.keys(require("./menu")).length}+ commandes_\n\nDéveloppé par *${config.AUTHOR}*\nVersion *${config.VERSION}*`
  });
}

async function theme(sock, msg, from, args) {
  await sock.sendMessage(from, { text: "🎨 Fonctionnalité de thème en cours de développement." });
}

async function gitclone(sock, msg, from, args) {
  const url = args[0];
  if (!url) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}gitclone <url>` });
  await sock.sendMessage(from, { text: `🔗 *Git Clone*\n\nPour cloner ce repo :\n\`git clone ${url}\`` });
}

module.exports = {
  ping, uptime, owner, developpeur, system_status, translate, qr,
  tempmail, tempinbox, capture, repo, support, pair, test,
  tovv, vv, vv2, obfuscate, description, theme, gitclone,
};
