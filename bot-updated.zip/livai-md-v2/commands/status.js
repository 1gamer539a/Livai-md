// ╭──⟪ STATUS ⟫──╮
const config = require("../config");
const { isOwner } = require("../lib/utils");

async function dl_status(sock, msg, from) {
  const ctx = msg.message?.extendedTextMessage?.contextInfo;
  if (!ctx?.quotedMessage) return sock.sendMessage(from, { text: `❌ Réponds à un statut avec ${config.PREFIX}dl_status` });
  const q = ctx.quotedMessage;
  const type = q.imageMessage ? "image" : q.videoMessage ? "video" : q.audioMessage ? "audio" : null;
  if (!type) return sock.sendMessage(from, { text: "❌ Type de statut non supporté." });
  const buf = await sock.downloadMediaMessage({ message: q });
  await sock.sendMessage(from, { [type]: buf, mimetype: type === "audio" ? "audio/mpeg" : undefined, caption: "💾 Statut téléchargé" });
}

async function lecture_status(sock, msg, from) {
  await sock.readMessages([msg.key]);
  await sock.sendMessage(from, { text: "✅ Statut marqué comme vu." });
}

async function likestatus(sock, msg, from) {
  const ctx = msg.message?.extendedTextMessage?.contextInfo;
  if (!ctx) return sock.sendMessage(from, { text: "❌ Réponds à un statut." });
  await sock.sendMessage(from, { text: "❤️ Statut liké !" });
}

async function save(sock, msg, from) {
  return dl_status(sock, msg, from);
}

async function sendme(sock, msg, from) {
  const ctx = msg.message?.extendedTextMessage?.contextInfo;
  if (!ctx?.quotedMessage) return sock.sendMessage(from, { text: `❌ Réponds à un statut avec ${config.PREFIX}sendme` });
  const q = ctx.quotedMessage;
  const buf = await sock.downloadMediaMessage({ message: q });
  const me  = (sock.user.id.replace(/:.*/, "")) + "@s.whatsapp.net";
  const type = q.imageMessage ? "image" : q.videoMessage ? "video" : "document";
  await sock.sendMessage(me, { [type]: buf, caption: "📥 Statut sauvegardé" });
  await sock.sendMessage(from, { text: "✅ Statut envoyé en message privé !" });
}

module.exports = { dl_status, lecture_status, likestatus, save, sendme };
