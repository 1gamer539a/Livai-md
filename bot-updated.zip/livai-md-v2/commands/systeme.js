// ╭──⟪ SYSTÈME ⟫──╮
const fs     = require("fs-extra");
const path   = require("path");
const config = require("../config");
const { isOwner } = require("../lib/utils");

const VAR_FILE = path.join(__dirname, "../data/vars.json");
function loadVars() { return fs.existsSync(VAR_FILE) ? fs.readJsonSync(VAR_FILE) : {}; }
function saveVars(v) { fs.writeJsonSync(VAR_FILE, v, { spaces:2 }); }

async function setvar(sock, msg, from, args) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  const key = args[0], val = args.slice(1).join(" ");
  if (!key || !val) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}setvar <clé> <valeur>` });
  const vars = loadVars();
  vars[key] = val;
  saveVars(vars);
  await sock.sendMessage(from, { text: `✅ Variable définie : *${key}* = \`${val}\`` });
}

async function getvar(sock, msg, from, args) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  const key  = args[0];
  const vars = loadVars();
  if (!key) {
    const list = Object.entries(vars).map(([k,v])=>`• *${k}* : \`${v}\``).join("\n");
    return sock.sendMessage(from, { text: `📋 *Variables*\n\n${list||"Aucune variable."}` });
  }
  const val = vars[key];
  await sock.sendMessage(from, { text: val ? `📌 *${key}* = \`${val}\`` : `❌ Variable *${key}* introuvable.` });
}

async function delvar(sock, msg, from, args) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  const key  = args[0];
  if (!key) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}delvar <clé>` });
  const vars = loadVars();
  delete vars[key];
  saveVars(vars);
  await sock.sendMessage(from, { text: `✅ Variable *${key}* supprimée.` });
}

async function checkupdate(sock, msg, from) {
  await sock.sendMessage(from, { text: `🔄 *Vérification des mises à jour*\n\nVersion actuelle : *${config.VERSION}*\nVérifie sur GitHub : https://github.com/TON_GITHUB/livai-md-v2` });
}

async function update(sock, msg, from) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  await sock.sendMessage(from, { text: "🔄 Mise à jour lancée via `git pull` sur le serveur Render." });
}

module.exports = { setvar, getvar, delvar, checkupdate, update };
