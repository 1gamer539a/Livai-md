// ╭──⟪ IMAGE EDITS ⟫──╮
const axios  = require("axios");
const { getQuoted } = require("../lib/utils");
const config = require("../config");

async function getImgBuf(sock, msg) {
  const q = getQuoted(msg);
  if (!q?.imageMessage) return null;
  return sock.downloadMediaMessage({ message: q });
}

// Helper via API canvas/siputzx
async function apiEdit(sock, msg, from, endpoint, caption) {
  const buf = await getImgBuf(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à une image avec cette commande.` });
  try {
    const b64  = buf.toString("base64");
    const res  = await axios.post(`https://api.siputzx.my.id/api/filter/${endpoint}`, { image: b64 }, { responseType:"arraybuffer" });
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption });
  } catch {
    await sock.sendMessage(from, { text: `❌ Erreur lors du traitement de l'image.` });
  }
}

// Sharp-based edits (local, no API needed)
async function sharpEdit(sock, msg, from, fn, caption) {
  const buf = await getImgBuf(sock, msg);
  if (!buf) return sock.sendMessage(from, { text: `❌ Réponds à une image.` });
  try {
    const sharp = require("sharp");
    const out   = await fn(sharp(buf));
    await sock.sendMessage(from, { image: out, caption });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur traitement image." });
  }
}

const blur       = (s,m,f) => sharpEdit(s,m,f, i=>i.blur(10).toBuffer(), "💨 Flou");
const greyscale  = (s,m,f) => sharpEdit(s,m,f, i=>i.greyscale().toBuffer(), "⬛ Niveaux de gris");
const sepia      = (s,m,f) => sharpEdit(s,m,f, i=>i.tint({r:112,g:66,b:20}).toBuffer(), "🟫 Sépia");
const invert1    = (s,m,f) => sharpEdit(s,m,f, i=>i.negate().toBuffer(), "🔄 Inversé");
const darkness   = (s,m,f) => sharpEdit(s,m,f, i=>i.modulate({brightness:0.4}).toBuffer(), "🌑 Assombri");
const rainbow    = (s,m,f) => sharpEdit(s,m,f, i=>i.modulate({hue:120}).toBuffer(), "🌈 Arc-en-ciel");
const pixelate   = (s,m,f) => sharpEdit(s,m,f, async i=>{
  const m2 = await i.metadata();
  return i.resize(Math.floor(m2.width/10),Math.floor(m2.height/10)).resize(m2.width,m2.height,{kernel:"nearest"}).toBuffer();
}, "🟦 Pixelisé");
const threshold  = (s,m,f) => sharpEdit(s,m,f, i=>i.threshold(128).toBuffer(), "⬜ Seuil");

// API-based edits
const affect       = (s,m,f) => apiEdit(s,m,f,"affect","😮 Affect");
const beautiful    = (s,m,f) => apiEdit(s,m,f,"beautiful","😍 Beautiful");
const circle1      = (s,m,f) => apiEdit(s,m,f,"circle","⭕ Circle");
const colorfy      = (s,m,f) => apiEdit(s,m,f,"colorfy","🎨 Colorfy");
const facepalmm    = (s,m,f) => apiEdit(s,m,f,"facepalm","🤦 Facepalm");
const jail         = (s,m,f) => apiEdit(s,m,f,"jail","⛓ Jail");
const jokeoverhead = (s,m,f) => apiEdit(s,m,f,"jokeoverhead","😂 Joke Overhead");
const rip          = (s,m,f) => apiEdit(s,m,f,"rip","🪦 R.I.P");
const trash        = (s,m,f) => apiEdit(s,m,f,"trash","🗑 Trash");
const trigger      = (s,m,f) => apiEdit(s,m,f,"trigger","⚡ Triggered");
const wanted       = (s,m,f) => apiEdit(s,m,f,"wanted","🤠 Wanted");
const wasted       = (s,m,f) => apiEdit(s,m,f,"wasted","💀 Wasted");

async function delete_image(sock, msg, from) {
  const q = getQuoted(msg);
  if (!q) return sock.sendMessage(from, { text: "❌ Réponds au message à supprimer." });
  await sock.sendMessage(from, { delete: msg.message?.extendedTextMessage?.contextInfo?.stanzaId
    ? { ...msg.key, id: msg.message.extendedTextMessage.contextInfo.stanzaId } : msg.key });
}

module.exports = {
  blur, greyscale, sepia, invert1, darkness, rainbow, pixelate, threshold,
  affect, beautiful, circle1, colorfy, facepalmm, jail, jokeoverhead,
  rip, trash, trigger, wanted, wasted, delete_image,
};
