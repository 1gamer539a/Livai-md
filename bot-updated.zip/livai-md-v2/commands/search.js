// ╭──⟪ SEARCH ⟫──╮
const axios  = require("axios");
const config = require("../config");

async function google(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}google <recherche>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/s/google?q=${encodeURIComponent(q)}`);
    const results = res.data?.data?.slice(0,3) || [];
    if (!results.length) return sock.sendMessage(from, { text: "❌ Aucun résultat." });
    const txt = results.map((r,i)=>`*${i+1}. ${r.title}*\n${r.description}\n🔗 ${r.url}`).join("\n\n");
    await sock.sendMessage(from, { text: `🔍 *Google — "${q}"*\n\n${txt}` });
  } catch {
    await sock.sendMessage(from, { text: `🔍 Recherche sur Google : https://www.google.com/search?q=${encodeURIComponent(q)}` });
  }
}

async function wiki(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}wiki <sujet>` });
  try {
    const res = await axios.get(`https://fr.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q)}`);
    const d   = res.data;
    const txt = `📚 *${d.title}*\n\n${d.extract.slice(0,800)}...\n\n🔗 ${d.content_urls.desktop.page}`;
    if (d.thumbnail?.source) {
      await sock.sendMessage(from, { image: { url: d.thumbnail.source }, caption: txt });
    } else {
      await sock.sendMessage(from, { text: txt });
    }
  } catch {
    await sock.sendMessage(from, { text: "❌ Article Wikipedia introuvable." });
  }
}

async function meteo(sock, msg, from, args) {
  const ville = args.join(" ");
  if (!ville) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}meteo <ville>` });
  try {
    const res  = await axios.get(`https://wttr.in/${encodeURIComponent(ville)}?format=j1`);
    const cur  = res.data.current_condition[0];
    const desc = cur.lang_fr?.[0]?.value || cur.weatherDesc[0].value;
    await sock.sendMessage(from, {
      text: `🌍 *Météo — ${ville}*\n\n🌡 Temp : *${cur.temp_C}°C* (ressenti ${cur.FeelsLikeC}°C)\n☁️ ${desc}\n💧 Humidité : ${cur.humidity}%\n💨 Vent : ${cur.windspeedKmph} km/h`
    });
  } catch {
    await sock.sendMessage(from, { text: "❌ Ville introuvable." });
  }
}

async function img(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}img <recherche>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/s/bing-image?q=${encodeURIComponent(q)}`);
    const url  = res.data?.data?.[0];
    if (!url) throw new Error();
    await sock.sendMessage(from, { image: { url }, caption: `🖼 *${q}*` });
  } catch {
    await sock.sendMessage(from, { text: `🔍 Recherche d'images : https://www.google.com/search?q=${encodeURIComponent(q)}&tbm=isch` });
  }
}

async function anime(sock, msg, from, args) {
  const q = args.join(" ");
  try {
    const res = await axios.get(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(q||"")}&limit=1`);
    const a   = res.data.data[0];
    if (!a) return sock.sendMessage(from, { text: "❌ Anime introuvable." });
    await sock.sendMessage(from, {
      image: { url: a.images.jpg.image_url },
      caption: `🎌 *${a.title}*\n\n⭐ Score : ${a.score}/10\n📺 Épisodes : ${a.episodes||"?"}\n📖 ${a.synopsis?.slice(0,300)||""}...`
    });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur recherche anime." });
  }
}

async function lyrics(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}lyrics <titre artiste>` });
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/s/lyrics?q=${encodeURIComponent(q)}`);
    const d   = res.data?.data;
    if (!d) throw new Error();
    await sock.sendMessage(from, { text: `🎵 *${d.title}* — ${d.artist}\n\n${d.lyrics?.slice(0,1500)}...` });
  } catch {
    await sock.sendMessage(from, { text: "❌ Paroles introuvables." });
  }
}

async function github(sock, msg, from, args) {
  const user = args[0];
  if (!user) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}github <username>` });
  try {
    const res = await axios.get(`https://api.github.com/users/${user}`);
    const u   = res.data;
    await sock.sendMessage(from, {
      image: { url: u.avatar_url },
      caption: `🐙 *${u.name||u.login}*\n\n👤 ${u.login}\n📖 ${u.bio||"Pas de bio"}\n📦 Repos : ${u.public_repos}\n👥 Followers : ${u.followers}\n🔗 ${u.html_url}`
    });
  } catch {
    await sock.sendMessage(from, { text: "❌ Utilisateur GitHub introuvable." });
  }
}

async function imdb(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}imdb <film/série>` });
  try {
    const res = await axios.get(`https://www.omdbapi.com/?apikey=trilogy&s=${encodeURIComponent(q)}&type=movie`);
    const m   = res.data.Search?.[0];
    if (!m) return sock.sendMessage(from, { text: "❌ Résultat IMDB introuvable." });
    await sock.sendMessage(from, { image: { url: m.Poster !== "N/A" ? m.Poster : "" }, caption: `🎬 *${m.Title}*\n📅 ${m.Year}\n🆔 IMDB: ${m.imdbID}` });
  } catch {
    await sock.sendMessage(from, { text: "❌ Erreur IMDB." });
  }
}

async function shazam(sock, msg, from) {
  await sock.sendMessage(from, { text: "🎵 Shazam nécessite une clé API RapidAPI. Configure SHAZAM_KEY dans config.js" });
}

async function stickersearch(sock, msg, from, args) {
  const q = args.join(" ");
  if (!q) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}stickersearch <terme>` });
  await sock.sendMessage(from, { text: `🔍 Recherche de stickers : "${q}"\n\nFonctionnalité à connecter avec une API de stickers.` });
}

module.exports = { google, wiki, meteo, img, anime, lyrics, github, imdb, shazam, stickersearch };
