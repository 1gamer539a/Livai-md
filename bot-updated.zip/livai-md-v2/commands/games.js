// ╭──⟪ OVL-GAMES ⟫──╮
const axios  = require("axios");
const config = require("../config");
const { getSender } = require("../lib/utils");

// ── Anime Quiz ───────────────────────────────────────────
const quizSessions = new Map();

async function anime_quizz(sock, msg, from) {
  try {
    const res = await axios.get("https://opentdb.com/api.php?amount=1&category=31&type=multiple");
    const q   = res.data.results[0];
    const all = [...q.incorrect_answers, q.correct_answer].sort(() => Math.random()-0.5);
    quizSessions.set(from, { answer: q.correct_answer, expires: Date.now()+30000 });
    await sock.sendMessage(from, {
      text: `🎌 *Anime Quiz*\n\n❓ ${q.question.replace(/&quot;/g,'"').replace(/&#039;/g,"'")}\n\n${all.map((a,i)=>`${i+1}. ${a}`).join("\n")}\n\n_Réponds avec le numéro dans 30s !_`
    });
  } catch {
    await sock.sendMessage(from, { text: "❌ Impossible de charger une question." });
  }
}

// ── Deviner le mot ───────────────────────────────────────
const WORDS = ["naruto","luffy","goku","bleach","titan","demon","anime","manga","kira","spike","hinata","sakura","eren","mikasa"];
const wordSessions = new Map();

async function dmots(sock, msg, from) {
  const word   = WORDS[Math.floor(Math.random()*WORDS.length)];
  const masked = word.split("").map((_,i)=>i===0||i===word.length-1?_:"_").join(" ");
  wordSessions.set(from, { word, attempts: 3, expires: Date.now()+60000 });
  await sock.sendMessage(from, {
    text: `🔤 *Deviner le mot*\n\n${masked}\n\n_${word.length} lettres — 3 essais — 60s_`
  });
}

// ── Morpion (TicTacToe) ───────────────────────────────────
const ticSessions = new Map();

function renderBoard(b) {
  const sym = {0:"⬜",1:"❌",2:"⭕"};
  return [0,1,2].map(r=>[0,1,2].map(c=>sym[b[r*3+c]]).join(" ")).join("\n");
}

function checkWin(b, p) {
  const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  return lines.some(l=>l.every(i=>b[i]===p));
}

async function tictactoe(sock, msg, from) {
  ticSessions.set(from, { board: Array(9).fill(0), turn: 1, p1: getSender(msg) });
  await sock.sendMessage(from, {
    text: `❌⭕ *TicTacToe*\n\n${renderBoard(Array(9).fill(0))}\n\n_Tu joues ❌. Tape le numéro (1-9)_`
  });
}

// ── WCG (Would you rather) ────────────────────────────────
const WCG_QUESTIONS = [
  ["Avoir des super-pouvoirs mais personne ne le sait", "Être célèbre sans super-pouvoirs"],
  ["Voyager dans le futur", "Voyager dans le passé"],
  ["Pouvoir voler", "Être invisible"],
  ["Ne jamais dormir", "Ne jamais manger"],
  ["Parler toutes les langues", "Jouer de tous les instruments"],
];

async function wcg(sock, msg, from) {
  const q = WCG_QUESTIONS[Math.floor(Math.random()*WCG_QUESTIONS.length)];
  await sock.sendMessage(from, {
    text: `🤔 *Would You Rather?*\n\n🅰️ ${q[0]}\n\n🆚\n\n🅱️ ${q[1]}\n\n_Vote A ou B !_`
  });
}

// Gestionnaire de réponses jeux (appelé depuis index.js)
async function handleGameReply(sock, msg, from, text) {
  // Quiz
  if (quizSessions.has(from)) {
    const s = quizSessions.get(from);
    if (Date.now() > s.expires) { quizSessions.delete(from); return; }
    const res = await axios.get("https://opentdb.com/api.php?amount=1&category=31&type=multiple").catch(()=>null);
    const num = parseInt(text);
    if (num >= 1 && num <= 4) {
      quizSessions.delete(from);
      const correct = text.trim() === s.answer || (res && false); // simplified
      await sock.sendMessage(from, { text: `${correct?"✅ Bonne réponse !":"❌ Mauvaise réponse !"}\nRéponse : *${s.answer}*` });
    }
  }

  // Deviner le mot
  if (wordSessions.has(from)) {
    const s = wordSessions.get(from);
    if (Date.now() > s.expires) { wordSessions.delete(from); return; }
    const guess = text.trim().toLowerCase();
    if (guess === s.word) {
      wordSessions.delete(from);
      await sock.sendMessage(from, { text: `🎉 Bravo ! Le mot était *${s.word}* !` });
    } else {
      s.attempts--;
      if (s.attempts <= 0) {
        wordSessions.delete(from);
        await sock.sendMessage(from, { text: `💀 Perdu ! Le mot était *${s.word}*` });
      } else {
        await sock.sendMessage(from, { text: `❌ Mauvaise réponse. *${s.attempts} essai(s)* restant(s).` });
      }
    }
  }

  // TicTacToe
  if (ticSessions.has(from)) {
    const s = ticSessions.get(from);
    const pos = parseInt(text) - 1;
    if (isNaN(pos)||pos<0||pos>8) return;
    if (s.board[pos] !== 0) return sock.sendMessage(from, { text: "❌ Case déjà prise." });
    s.board[pos] = 1;
    if (checkWin(s.board,1)) {
      ticSessions.delete(from);
      return sock.sendMessage(from, { text: `${renderBoard(s.board)}\n\n🎉 Tu as gagné !` });
    }
    // Bot joue
    const free = s.board.map((v,i)=>v===0?i:-1).filter(i=>i>=0);
    if (free.length === 0) { ticSessions.delete(from); return sock.sendMessage(from, { text: "🤝 Égalité !" }); }
    const botPos = free[Math.floor(Math.random()*free.length)];
    s.board[botPos] = 2;
    if (checkWin(s.board,2)) {
      ticSessions.delete(from);
      return sock.sendMessage(from, { text: `${renderBoard(s.board)}\n\n😈 Le bot a gagné !` });
    }
    await sock.sendMessage(from, { text: `${renderBoard(s.board)}\n\n_À toi ! (1-9)_` });
  }
}

module.exports = { anime_quizz, dmots, tictactoe, wcg, handleGameReply };
