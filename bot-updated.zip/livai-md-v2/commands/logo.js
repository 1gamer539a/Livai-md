// ╭──⟪ LOGO ⟫──╮
const axios  = require("axios");
const config = require("../config");

// Tous les styles disponibles → API textpro.me / siputzx / pngbix
const LOGO_STYLES = [
  "avengers","blackpink","blackpink2","blackpink3","boobs","captain_america",
  "cloud","cloud2","cubic","deadpool","dragonball","dragonball2","effacer",
  "football","football2","football3","futuris","galaxy","glass",
  "gold1","gold2","gold3","gold4","gold5","graffiti1","graffiti2","graffiti3",
  "green_effect","hacker","metal","naruto","neon1","neon2","neon3",
  "onepiece","paint","plasma","rain","sand","sci_fi","space","steel",
  "summery","thor","thunder","typography","underwater","vintage","watercolor","wood",
];

async function makeLogo(sock, msg, from, style, args) {
  const text = args.join(" ");
  if (!text) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}${style} <texte>` });
  await sock.sendMessage(from, { text: `🎨 Génération du logo *${style}*...` });
  try {
    // On essaie textpro.me d'abord
    const res = await axios.get(
      `https://api.siputzx.my.id/api/maker/logo?style=${encodeURIComponent(style)}&text=${encodeURIComponent(text)}`,
      { responseType: "arraybuffer" }
    );
    await sock.sendMessage(from, { image: Buffer.from(res.data), caption: `🎨 *${style.toUpperCase()}*\n_${text}_` });
  } catch {
    // Fallback : API canvas textpro
    try {
      const res2 = await axios.get(
        `https://api.textpro.me/${style}.php?text=${encodeURIComponent(text)}`,
        { responseType: "arraybuffer" }
      );
      await sock.sendMessage(from, { image: Buffer.from(res2.data), caption: `🎨 *${style.toUpperCase()}*\n_${text}_` });
    } catch {
      await sock.sendMessage(from, { text: `❌ Style *${style}* indisponible pour le moment.` });
    }
  }
}

// Exporter une fonction par style
const exports_ = {};
for (const style of LOGO_STYLES) {
  exports_[style] = (sock, msg, from, args) => makeLogo(sock, msg, from, style, args);
}

module.exports = exports_;
