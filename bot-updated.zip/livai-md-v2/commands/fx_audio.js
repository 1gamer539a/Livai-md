// ╭──⟪ FX AUDIO ⟫──╮
const { execSync } = require("child_process");
const fs     = require("fs-extra");
const path   = require("path");
const { getQuoted } = require("../lib/utils");

// Filtres ffmpeg pour chaque effet
const FX = {
  alien:       "aecho=0.8:0.88:60:0.4,vibrato=f=20:d=0.5",
  bass:        "bass=g=20",
  blown:       "aecho=0.8:0.88:500:0.6",
  buzz:        "afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)':win_size=512:overlap=0.75",
  cave:        "aecho=0.8:0.88:500:0.5,aecho=0.8:0.88:1000:0.3",
  chipmunk:    "asetrate=44100*1.6,atempo=0.8",
  chorus:      "chorus=0.7:0.9:55:0.4:0.25:2",
  compressor:  "acompressor=threshold=0.05:ratio=20:attack=5:release=50",
  dark:        "asetrate=44100*0.75,atempo=1.3",
  deep:        "asetrate=44100*0.6,atempo=1.5",
  distortion:  "acrusher=level_in=4:level_out=4:bits=8:mode=log:aa=1",
  dizzy:       "chorus=0.5:0.9:50|60:0.4|0.32:0.25|0.4:2|1.3",
  earrape:     "acrusher=level_in=10:level_out=10:bits=4:mode=lin:aa=0",
  echo:        "aecho=0.8:0.9:1000:0.3",
  fast:        "atempo=1.5",
  fat:         "aecho=0.6:0.6:10:0.2",
  flanger:     "flanger=delay=0:depth=2:regen=0:width=71:speed=0.5:shape=sinusoidal:phase=25:interp=linear",
  ghost:       "aecho=0.9:0.9:1000|1800:0.3|0.25",
  haunting:    "aecho=0.8:0.9:800|1600:0.4|0.3,vibrato=f=2:d=0.3",
  invert:      "aeval='-val(0)':c=same",
  lofi:        "lowpass=f=3000,aecho=0.8:0.88:60:0.4",
  mono:        "pan=mono|c0=c0",
  muted:       "lowpass=f=800",
  nightcore:   "asetrate=44100*1.25,atempo=1.0",
  panorama:    "apulsator=hz=0.5",
  phaser:      "aphaser=in_gain=0.4:out_gain=0.74:delay=3:decay=0.4:speed=0.5:type=t",
  radio:       "lowpass=f=3000,highpass=f=300,aecho=0.4:0.4:60:0.1",
  reverb:      "aecho=0.8:0.88:60:0.4,aecho=0.8:0.88:120:0.3",
  reverse:     "areverse",
  robot:       "afftfilt=real='hypot(re,im)':imag='0':win_size=512:overlap=0.75",
  slow:        "atempo=0.7",
  smooth:      "highpass=f=200,lowpass=f=5000,acompressor=threshold=0.03:ratio=3",
  space:       "aecho=0.8:0.88:1000|1800:0.5|0.3",
  squirrel:    "asetrate=44100*2,atempo=0.5",
  surround:    "apulsator=hz=1.5",
  telephone:   "highpass=f=300,lowpass=f=3400",
  tremolo:     "tremolo=f=5:d=0.7",
  underwater:  "lowpass=f=800,aecho=0.9:0.9:1000:0.5",
  vibrato:     "vibrato=f=7:d=0.5",
  vintage:     "lowpass=f=4000,aecho=0.8:0.88:40:0.3,acrusher=bits=10:mode=lin:aa=0",
};

async function applyFX(sock, msg, from, effectName) {
  const quoted = getQuoted(msg);
  if (!quoted?.audioMessage && !quoted?.videoMessage)
    return sock.sendMessage(from, { text: `❌ Réponds à un audio avec .${effectName}` });

  const filter = FX[effectName];
  if (!filter) return sock.sendMessage(from, { text: "❌ Effet inconnu." });

  await sock.sendMessage(from, { text: `⏳ Application de l'effet *${effectName}*...` });

  const tmpIn  = path.join("/tmp", `in_${Date.now()}.mp3`);
  const tmpOut = path.join("/tmp", `out_${Date.now()}.mp3`);

  try {
    const buf = await sock.downloadMediaMessage({ message: quoted });
    fs.writeFileSync(tmpIn, buf);
    execSync(`ffmpeg -y -i "${tmpIn}" -af "${filter}" "${tmpOut}" 2>/dev/null`);
    const outBuf = fs.readFileSync(tmpOut);
    await sock.sendMessage(from, { audio: outBuf, mimetype: "audio/mpeg", ptt: true });
  } catch (e) {
    await sock.sendMessage(from, { text: `❌ Erreur lors de l'application de l'effet.\n_${e.message}_` });
  } finally {
    fs.removeSync(tmpIn);
    fs.removeSync(tmpOut);
  }
}

// Exporter une fonction par effet
const exports_ = {};
for (const name of Object.keys(FX)) {
  exports_[name] = (sock, msg, from) => applyFX(sock, msg, from, name);
}

module.exports = exports_;
