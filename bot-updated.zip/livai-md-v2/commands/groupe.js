// ╭──⟪ GROUPE ⟫──╮
const config = require("../config");
const store  = require("../lib/store");
const { isOwner, getSender, isAdmin, isBotAdmin, getMentioned } = require("../lib/utils");

// ── Helpers ──────────────────────────────────────────────
async function requireAdmin(sock, msg, from) {
  const sender = getSender(msg);
  const ok = await isAdmin(sock, from, sender) || isOwner(msg);
  if (!ok) { await sock.sendMessage(from, { text: "❌ Réservé aux admins." }); return false; }
  return true;
}
async function requireBotAdmin(sock, from) {
  const ok = await isBotAdmin(sock, from);
  if (!ok) { await sock.sendMessage(from, { text: "❌ Je dois être admin du groupe." }); return false; }
  return true;
}
function requireGroup(sock, msg, from) {
  if (!from.endsWith("@g.us")) { sock.sendMessage(from, { text: "❌ Réservé aux groupes." }); return false; }
  return true;
}

// ── COMMANDES ────────────────────────────────────────────

async function kick(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  if (!await requireBotAdmin(sock, from)) return;
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ Mentionne quelqu'un. Ex: ${config.PREFIX}kick @membre` });
  await sock.groupParticipantsUpdate(from, targets, "remove");
  await sock.sendMessage(from, { text: `✅ ${targets.map(t=>"@"+t.split("@")[0]).join(", ")} expulsé(s).`, mentions: targets });
}

async function kickall(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  if (!await requireBotAdmin(sock, from)) return;
  const meta    = await sock.groupMetadata(from);
  const botId   = sock.user.id.replace(/:.*/, "") + "@s.whatsapp.net";
  const members = meta.participants.filter(p => p.id !== botId && !p.admin).map(p => p.id);
  if (!members.length) return sock.sendMessage(from, { text: "ℹ️ Aucun membre à expulser." });
  await sock.groupParticipantsUpdate(from, members, "remove");
  await sock.sendMessage(from, { text: `✅ ${members.length} membres expulsés.` });
}

async function ckick(sock, msg, from, args) {
  // kick conditionnel — kick le premier non-admin
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  if (!await requireBotAdmin(sock, from)) return;
  const meta    = await sock.groupMetadata(from);
  const botId   = sock.user.id.replace(/:.*/, "") + "@s.whatsapp.net";
  const target  = meta.participants.find(p => !p.admin && p.id !== botId);
  if (!target) return sock.sendMessage(from, { text: "ℹ️ Aucun membre non-admin." });
  await sock.groupParticipantsUpdate(from, [target.id], "remove");
  await sock.sendMessage(from, { text: `✅ @${target.id.split("@")[0]} expulsé.`, mentions:[target.id] });
}

async function promote(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  if (!await requireBotAdmin(sock, from)) return;
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}promote @membre` });
  await sock.groupParticipantsUpdate(from, targets, "promote");
  await sock.sendMessage(from, { text: `👑 ${targets.map(t=>"@"+t.split("@")[0]).join(", ")} promu(s) admin !`, mentions: targets });
}

async function demote(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  if (!await requireBotAdmin(sock, from)) return;
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}demote @admin` });
  await sock.groupParticipantsUpdate(from, targets, "demote");
  await sock.sendMessage(from, { text: `⬇️ ${targets.map(t=>"@"+t.split("@")[0]).join(", ")} rétrogradé(s).`, mentions: targets });
}

async function mute(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  await sock.groupSettingUpdate(from, "announcement");
  await sock.sendMessage(from, { text: "🔇 Groupe mis en silencieux. Seuls les admins peuvent écrire." });
}

async function unmute(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  await sock.groupSettingUpdate(from, "not_announcement");
  await sock.sendMessage(from, { text: "🔊 Groupe réactivé. Tout le monde peut écrire." });
}

// Alias close/open
const close = mute;
const open  = unmute;

async function lock(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  await sock.groupSettingUpdate(from, "locked");
  await sock.sendMessage(from, { text: "🔒 Seuls les admins peuvent modifier les infos du groupe." });
}

async function unlock(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  await sock.groupSettingUpdate(from, "unlocked");
  await sock.sendMessage(from, { text: "🔓 Tout le monde peut modifier les infos du groupe." });
}

async function tagall(sock, msg, from, args) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const meta    = await sock.groupMetadata(from);
  const members = meta.participants.map(p => p.id);
  const txt     = args.join(" ") || "📢 Attention !";
  const mentions_txt = members.map(m => `@${m.split("@")[0]}`).join(" ");
  await sock.sendMessage(from, { text: `${txt}\n\n${mentions_txt}`, mentions: members });
}

async function tag(sock, msg, from, args) {
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}tag @membre` });
  const txt = args.filter(a=>!a.startsWith("@")).join(" ") || "👋";
  await sock.sendMessage(from, { text: `${txt}\n${targets.map(t=>"@"+t.split("@")[0]).join(" ")}`, mentions: targets });
}

async function tagadmin(sock, msg, from, args) {
  if (!requireGroup(sock, msg, from)) return;
  const meta   = await sock.groupMetadata(from);
  const admins = meta.participants.filter(p => p.admin).map(p => p.id);
  const txt    = args.join(" ") || "📢 Admins !";
  await sock.sendMessage(from, { text: `${txt}\n${admins.map(a=>"@"+a.split("@")[0]).join(" ")}`, mentions: admins });
}

async function ginfo(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  const meta   = await sock.groupMetadata(from);
  const admins = meta.participants.filter(p => p.admin).length;
  await sock.sendMessage(from, {
    text: `📋 *Infos du groupe*\n\n` +
      `• Nom : *${meta.subject}*\n` +
      `• ID : \`${from}\`\n` +
      `• Membres : *${meta.participants.length}*\n` +
      `• Admins : *${admins}*\n` +
      `• Créé le : ${new Date(meta.creation*1000).toLocaleDateString("fr-FR")}\n` +
      `• Description : _${meta.desc||"Aucune"}_`
  });
}

async function gname(sock, msg, from, args) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const name = args.join(" ");
  if (!name) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}gname <nouveau nom>` });
  await sock.groupUpdateSubject(from, name);
  await sock.sendMessage(from, { text: `✅ Nom du groupe mis à jour : *${name}*` });
}

async function gdesc(sock, msg, from, args) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const desc = args.join(" ");
  if (!desc) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}gdesc <description>` });
  await sock.groupUpdateDescription(from, desc);
  await sock.sendMessage(from, { text: `✅ Description mise à jour.` });
}

async function link(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const code = await sock.groupInviteCode(from);
  await sock.sendMessage(from, { text: `🔗 *Lien d'invitation*\nhttps://chat.whatsapp.com/${code}` });
}

async function revoke(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  await sock.groupRevokeInvite(from);
  await sock.sendMessage(from, { text: "✅ Lien d'invitation révoqué." });
}

async function join(sock, msg, from, args) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  const inviteUrl = args[0];
  if (!inviteUrl) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}join <lien>` });
  const code = inviteUrl.split("chat.whatsapp.com/").pop();
  try {
    await sock.groupAcceptInvite(code);
    await sock.sendMessage(from, { text: "✅ Groupe rejoint !" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Impossible de rejoindre ce groupe." });
  }
}

async function leave(sock, msg, from) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  if (!requireGroup(sock, msg, from)) return;
  await sock.groupLeave(from);
}

async function gccreate(sock, msg, from, args) {
  if (!isOwner(msg)) return sock.sendMessage(from, { text: "❌ Réservé au owner." });
  const name = args.join(" ") || "OVL-MD Group";
  const me   = [sock.user.id];
  const grp  = await sock.groupCreate(name, me);
  await sock.sendMessage(from, { text: `✅ Groupe créé : *${name}*\nID : \`${grp.id}\`` });
}

async function getpp(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  try {
    const url = await sock.profilePictureUrl(from, "image");
    await sock.sendMessage(from, { image: { url }, caption: "🖼 Photo du groupe" });
  } catch {
    await sock.sendMessage(from, { text: "❌ Aucune photo de groupe." });
  }
}

async function updatepp(sock, msg, from) {
  const { getQuoted } = require("../lib/utils");
  const q = getQuoted(msg);
  if (!q?.imageMessage) return sock.sendMessage(from, { text: `❌ Réponds à une image avec ${config.PREFIX}updatepp` });
  const buf = await sock.downloadMediaMessage({ message: q });
  await sock.updateProfilePicture(from, buf);
  await sock.sendMessage(from, { text: "✅ Photo du groupe mise à jour." });
}

async function removepp(sock, msg, from) {
  if (!await requireAdmin(sock, msg, from)) return;
  await sock.removeProfilePicture(from);
  await sock.sendMessage(from, { text: "✅ Photo du groupe supprimée." });
}

async function acceptall(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const pending = await sock.groupRequestParticipantsList(from);
  if (!pending.length) return sock.sendMessage(from, { text: "ℹ️ Aucune demande en attente." });
  await sock.groupRequestParticipantsUpdate(from, pending.map(p=>p.jid), "approve");
  await sock.sendMessage(from, { text: `✅ ${pending.length} demande(s) acceptée(s).` });
}

async function rejectall(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const pending = await sock.groupRequestParticipantsList(from);
  if (!pending.length) return sock.sendMessage(from, { text: "ℹ️ Aucune demande en attente." });
  await sock.groupRequestParticipantsUpdate(from, pending.map(p=>p.jid), "reject");
  await sock.sendMessage(from, { text: `✅ ${pending.length} demande(s) refusée(s).` });
}

async function vcf(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  const meta = await sock.groupMetadata(from);
  let vcfContent = "";
  for (const p of meta.participants) {
    const num = p.id.split("@")[0];
    vcfContent += `BEGIN:VCARD\nVERSION:3.0\nFN:+${num}\nTEL;TYPE=CELL:+${num}\nEND:VCARD\n`;
  }
  await sock.sendMessage(from, {
    document: Buffer.from(vcfContent),
    mimetype: "text/vcard",
    fileName: `${meta.subject}.vcf`,
    caption: `📋 Contacts du groupe (${meta.participants.length})`
  });
}

async function warn(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const targets = getMentioned(msg);
  if (!targets.length) return sock.sendMessage(from, { text: `❌ ${config.PREFIX}warn @membre` });
  for (const t of targets) {
    const count = store.addWarn(t);
    await sock.sendMessage(from, {
      text: `⚠️ @${t.split("@")[0]} a reçu un avertissement !\nTotal : *${count}/3*\n${count>=3?"🚨 Expulsion automatique !":""}`,
      mentions: [t]
    });
    if (count >= 3) {
      await sock.groupParticipantsUpdate(from, [t], "remove");
      store.resetWarn(t);
    }
  }
}

async function poll(sock, msg, from, args) {
  const parts = args.join(" ").split("|");
  if (parts.length < 3) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}poll Question | Option1 | Option2 | ...` });
  const question = parts[0].trim();
  const options  = parts.slice(1).map(o => o.trim());
  await sock.sendMessage(from, { poll: { name: question, values: options, selectableCount: 1 } });
}

async function poll2(sock, msg, from, args) {
  const parts = args.join(" ").split("|");
  if (parts.length < 3) return sock.sendMessage(from, { text: `❌ Usage : ${config.PREFIX}poll2 Question | Option1 | Option2 | ...` });
  const question = parts[0].trim();
  const options  = parts.slice(1).map(o => o.trim());
  await sock.sendMessage(from, { poll: { name: question, values: options, selectableCount: 0 } });
}

// ── ANTI- toggles ────────────────────────────────────────
async function antilink(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("antilinkGroups", from);
  await sock.sendMessage(from, { text: `🔗 Anti-lien : *${active?"✅ Activé":"❌ Désactivé"}*` });
}
async function antispam(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("antispamGroups", from);
  await sock.sendMessage(from, { text: `🛡 Anti-spam : *${active?"✅ Activé":"❌ Désactivé"}*` });
}
async function antibot(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("antibotGroups", from);
  await sock.sendMessage(from, { text: `🤖 Anti-bot : *${active?"✅ Activé":"❌ Désactivé"}*` });
}
async function antimentiongc(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("antimentionGroups", from);
  await sock.sendMessage(from, { text: `📢 Anti-mention GC : *${active?"✅ Activé":"❌ Désactivé"}*` });
}
async function antidemote(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("antidemoteGroups", from);
  await sock.sendMessage(from, { text: `⬇️ Anti-demote : *${active?"✅ Activé":"❌ Désactivé"}*` });
}
async function antipromote(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("antipromoteGroups", from);
  await sock.sendMessage(from, { text: `⬆️ Anti-promote : *${active?"✅ Activé":"❌ Désactivé"}*` });
}
async function antitag(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("antitagGroups", from);
  await sock.sendMessage(from, { text: `🏷 Anti-tag : *${active?"✅ Activé":"❌ Désactivé"}*` });
}

// ── Welcome / Goodbye ────────────────────────────────────
async function welcome(sock, msg, from, args) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const s = store.load();
  if (!s.welcomeGroups) s.welcomeGroups = {};
  if (args[0] === "off") {
    delete s.welcomeGroups[from];
    store.save(s);
    return sock.sendMessage(from, { text: "👋 Message de bienvenue désactivé." });
  }
  const txt = args.join(" ") || "Bienvenue @user dans le groupe !";
  s.welcomeGroups[from] = txt;
  store.save(s);
  await sock.sendMessage(from, { text: `✅ Message de bienvenue défini :\n_${txt}_` });
}

async function goodbye(sock, msg, from, args) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const s = store.load();
  if (!s.goodbyeGroups) s.goodbyeGroups = {};
  if (args[0] === "off") {
    delete s.goodbyeGroups[from];
    store.save(s);
    return sock.sendMessage(from, { text: "👋 Message d'au revoir désactivé." });
  }
  const txt = args.join(" ") || "Au revoir @user !";
  s.goodbyeGroups[from] = txt;
  store.save(s);
  await sock.sendMessage(from, { text: `✅ Message d'au revoir défini :\n_${txt}_` });
}

async function promotealert(sock, msg, from, args) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("promotealertGroups", from);
  await sock.sendMessage(from, { text: `📢 Alerte promotion : *${active?"✅ Activé":"❌ Désactivé"}*` });
}

async function demotealert(sock, msg, from) {
  if (!requireGroup(sock, msg, from)) return;
  if (!await requireAdmin(sock, msg, from)) return;
  const active = store.toggle("demotealertGroups", from);
  await sock.sendMessage(from, { text: `📢 Alerte rétrogradation : *${active?"✅ Activé":"❌ Désactivé"}*` });
}

module.exports = {
  kick, kickall, ckick, promote, demote, mute, unmute, close, open,
  lock, unlock, tagall, tag, tagadmin, ginfo, gname, gdesc, link, revoke,
  join, leave, gccreate, getpp, updatepp, removepp, acceptall, rejectall,
  vcf, warn, poll, poll2, antilink, antispam, antibot, antimentiongc,
  antidemote, antipromote, antitag, welcome, goodbye, promotealert, demotealert,
};
