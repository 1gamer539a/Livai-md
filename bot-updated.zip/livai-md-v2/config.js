// ╔══════════════════════════════════╗
// ║        LIVAÏ MD  — CONFIG       ║
// ╚══════════════════════════════════╝

module.exports = {
  BOT_NAME:      "Livaï MD",
  VERSION:       "2.1.3",
  AUTHOR:        "Livaï",
  OWNER_NAME:    "Livaï",
  OWNER_NUMBER:  process.env.OWNER_NUMBER || "242067803987",   // ← Ton numéro OU variable d'env Render
  PREFIX:        ".",
  PUBLIC_MODE:   true,
  COOLDOWN:      3000,            // ms entre 2 commandes
  SESSION_DIR:   "./auth_info",
  PLATFORM:      "Linux",
  BANNER_URL:    "https://i.imgur.com/yourbanner.jpg", // ← Ton image OVL-MD

  // Clés API (optionnelles — remplis selon ce que tu veux activer)
  OPENAI_KEY:    process.env.OPENAI_KEY    || "",
  GEMINI_KEY:    process.env.GEMINI_KEY    || "",
  WEATHER_KEY:   process.env.WEATHER_KEY   || "",   // openweathermap
};
