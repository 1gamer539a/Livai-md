# 《 OVL-MD-V2 》
> Bot WhatsApp Multi-Device | Baileys | Node.js  
> Développé par **Livaï** | Auteur : **Ainz**

---

## ⚡ Installation

```bash
git clone https://github.com/TON_GITHUB/ovl-md-v2.git
cd ovl-md-v2
npm install
```

### Configurer `config.js`
```js
OWNER_NAME:   "Livaï",
OWNER_NUMBER: "242XXXXXXXXX",  // ton numéro sans +
BANNER_URL:   "https://lien-de-ton-image.jpg",
// Optionnel :
OPENAI_KEY:   "sk-...",    // pour GPT et DALL·E
GEMINI_KEY:   "AIza...",   // pour Gemini
```

### Lancer
```bash
node index.js
```
📱 Scanne le QR avec **WhatsApp → Appareils connectés → Connecter un appareil**

---

## ☁️ Hébergement sur Render

| Étape | Action |
|---|---|
| 1 | Push sur GitHub |
| 2 | Render → **New → Background Worker** |
| 3 | Build Command : `npm install` |
| 4 | Start Command : `node index.js` |
| 5 | Lancer → Scanne le QR dans les logs |
| 6 | Bot actif 24h/24 ✅ |

> **Astuce Render** : Ajoute tes clés API dans **Environment Variables** (pas dans config.js)

---

## 📋 Catégories de commandes (335+)

| Catégorie | Commandes |
|---|---|
| 🔒 Confidentialité | getprivacy, groupadd, lastseen, mypp, mystatus, online, presence, read, setbio |
| 🔄 Conversion | sticker, toimage, toaudio, tts, ttp, attp, circle, crop, write, emix... |
| 🎉 Fun | blague, citation, ship, fake, fancy, fliptext, profile, rank... |
| 🎵 FX Audio | alien, bass, chipmunk, nightcore, reverb, robot, slow, fast... (40 effets) |
| 👥 Groupe | kick, mute, tagall, antilink, welcome, warn, poll, vcf... (40 cmds) |
| 🤖 IA | gpt, gemini, claude, blackbox, copilot, llama, dalle |
| 🖼 Image Edits | blur, sepia, greyscale, jail, rip, wanted, wasted, pixelate... |
| 🎨 Logo | avengers, neon1-3, dragonball, galaxy, graffiti1-3... (50+ styles) |
| 🛠 Outils | ping, translate, qr, tempmail, capture, system_status... |
| 💰 Economy | slot, pari, bonus, depot, transfer, vol, don... |
| 🎮 Games | anime-quizz, dmots, tictactoe, wcg |
| 👑 Owner | ban, block, restart, setsudo, tgs, anticall, antidelete... |
| 💞 Réaction | embrasser, gifler, danser, enlacer, tapoter... (27 réactions) |
| 🔍 Search | google, wiki, anime, github, lyrics, imdb, meteo... |
| 📺 Status | dl_status, lecture_status, save, sendme |
| ⚙️ Système | setvar, getvar, delvar, checkupdate, update |
| 📥 Téléchargement | yta, ytv, tiktok, igdl, fbdl, twitterdl, song, app... |

---

## 🛠 Ajouter une commande

1. Crée ou modifie un fichier dans `commands/`
2. Exporte ta fonction
3. Importe-la dans `index.js` et ajoute-la dans `COMMANDS`

```js
// commands/custom.js
async function macommande(sock, msg, from, args) {
  await sock.sendMessage(from, { text: "Hello World !" });
}
module.exports = { macommande };

// index.js — ajoute dans COMMANDS :
macommande: require("./commands/custom").macommande,
```

---

## 👑 Crédits

- **Owner / Hébergeur** : Livaï
- **Développeur** : Ainz
- **Framework** : [@whiskeysockets/baileys](https://github.com/WhiskeySockets/Baileys)
- **Version** : OVL-MD-V2 v2.1.3

> ©️2025 OVL-MD-V2 by *Ainz*
